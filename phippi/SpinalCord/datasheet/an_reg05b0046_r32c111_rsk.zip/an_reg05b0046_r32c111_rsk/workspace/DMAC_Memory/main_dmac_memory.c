/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_dmac_memory.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	:  This application demonstrates the configuration of DMAC with   
*				  fixed source as ADC and forward destination as memory block
*				  of 1024 bytes.
*
* Operation     : 1. Build this application and download it to the target.
*				  2. Click on the "Reset Go" icon available on 'Debug' toolbar. 
*				  3. This application configures DMAC with fixed source as ADC
*					 and forward destination as memory block of 1024 bytes. 
*				  4. The ADC channel AN0 is configured in oneshot mode, software 
*					 trigger. The result of ADC conversion is transferred to 
*					 memory array 'gDMA_DataBuff'. 
*				  5. The user may examine the DMAC transfer operation result 
*					 in a variable 'gDMA_DataBuff' using HEW C watch window. 
*				  6. While executing the application, please put a breakpoint
*					 at the while(1) statement, i.e. at the end of the main 
*					 function to confirm the completion of DMAC operation.   	 	
*
*
* Note: This file contains a compiler directive "#pragma interrupt 
* functionname" which instructs the compiler to treat the following 
* function as an interrupt. The compiler will save all registers
* used in the function and replace the normal RTS instruction with an REIT
* instruction at the end of the function.
*
* Note : This file contains a compiler directive 
* "#pragma DMAC variable_name DMAC_REGISTER_NAME" instructs the compiler
* to treat the 'variable' as DMAC register inside the CPU. 
*
******************************************************************************/ 

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main_dmac_memory.h"

/******************************************************************************
Global variables

******************************************************************************/
/* gDMA_DataBuff is a memory buffer of 1024 bytes. This memory buffer is 
   forward destination for DMA Operation */
unsigned short gDMA_DataBuff[ARRAY_SIZE];

/* DMAC Count register */
unsigned long dct0;
#pragma DMAC dct0 DCT0

/* DMAC source address register */
void _far *dsa0;
#pragma DMAC dsa0 DSA0

/* DMAC destination address register */
void _far *dda0;
#pragma DMAC dda0 DDA0

/* DMAC mode register */
unsigned long dmd0;
#pragma DMAC dmd0 DMD0

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routines for ADC and DMAC
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void main(void)				
{
	/* Configure the DMA channel 0 in fixed source, forward destination mode */
	Init_DMA0();
	
	/* Initialization of ADC in one shot mode, software trigger */
	Init_ADCOneShot();
	
	while (dct0)
	{
		/* Wait till DMAC count becomes zero */
	}
	
	/* This function must not exit. */
	while(1);
}         
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: Init_ADCOneShot
* Description 	: Configuration of ADC channel AN0 in one shot mode, 
*				  software triggered
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void Init_ADCOneShot(void)
{
	/* ADC conversion start flag. Set to 0 to stop ADC conversion */
	adst_ad0con0 = 0;
	
	/* ADC Control Register 0 
	b2:b1:b0	- CH2:CH1:CH0	- 000 (Analog Input Pin Select Bit. AN0 selected)
	b4:b3		- MD1:MD0		- 00  (ADC One-shot mode)
	b5			- TRG			- 0   (Software trigger)
	b6			- ADST			- 0   (AD conversion stopped)
	b7			- CKS0			- 1	  (Frequency select bit. fAD�1 selected) */
	
	ad0con0 = 0x80;
	
	/* ADC Control Register 1
	b1:b0	- SCAN1:SCAN0	- 00 (AN0 selected)
	b2		- MD2			- 0  (single sweep mode)
	b3		- BITS			- 1  (10 bit mode)
	b4		- CKS1			- 1  (Frequency select bit. fAD�1 selected)
	b5		- VCUT 			- 1  (VREF connected)
	b7:b6	- OPA1:OPA0		- 00 (Not applicable in this mode) */				
	
	ad0con1 = 0x38;
	
	/* ADC Control Register 2 
	b0		- SMP			- 1  (With sample & hold function)
	b2:b1	- APS1:APS0		- 00 (AN0 selected)
	b4:b3	- Reserved		- 00
	b5		- TRG0			- 0  (Not applicable in software trigger mode)
	b7:b6	- Reserved		- 00 */
	
	ad0con2 = 0x01;
	
	/* ADC Control Register 3
	b0			- DUS			- 0 (DMAC operating mode disabled)
	b1 			- MSS			- 0 (Multi-port sweep mode disabled)
	b2			- CKS2			- 0 (Frequency select bit. fAD�1 selected)
	b4:b3		- MSF1:MSF0		- 00 (AN0 selected)
	b5:b6:b7	- Reserved		- 000 */
    
	ad0con3 = 0x0;
	
	/* ADC Control Register 4
	b1:b0		- Reserved		- 00
	b3:b2		- MPS11:MPS10	- 00 (Not used)
	b7:b6:b5:b4 - Reserved		- 0000 */
	
	ad0con4 = 0x00;
	
	/* Disable interrupts	*/
	DISABLE_IRQ
	
	/* ADC Converter 0 Convert Completion Interrupt Control Register (AD0IC)
	b2:b1:b0	- ILVL2:ILVL1:ILVL0 - 001 (Interrupt priority level select.
											 Priority level 1 selected)
	b4 			- IR			  	 - 0   (Interrupt request bit. 
											 Interrupt not requested) 
	b7:b6:b5	- Reserved 			 - 000 */
		
	ad0ic = 0x01;
	
	/* Enable interrupts	*/
	ENABLE_IRQ	
	
	/* ADC conversion start flag. Set to 1 to start ADC conversion */
	adst_ad0con0 = 1;
}
/******************************************************************************
End of function Init_ADCOneShot
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: Init_DMA0
* Description 	: Configures the DMAC channel 0 in fixed source and 	
*				  forward destination mode
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void Init_DMA0(void)
{
	/* Delay Count */
	unsigned short delayCnt = 0x0fff;
	
	/* Set DMA transfer count */
	dct0 = ARRAY_SIZE;
	
	/* Set DMA Source Address as AD0 register */
	dsa0 = (unsigned long *)&ad00;
		
	/* Set DMA Destination Address */
	dda0 = (unsigned long *)&gDMA_DataBuff;
	
	/* DMA0 Request Source Select Register, Select ADC0 interrupt request */
	dm0sl = 0x18;
	
	/* DMA0 Request Source Select Register, Reserved */
	dm0sl2 = 0x00;
	
	while (delayCnt--)
	{
		/* Delay loop */	
	}

	/* DMA0 Mode Register
	b1:b0	- MD01:MD00		- 01 (Single transfer)
	b3:b2	- BW01:BW00		- 01 (16 bits mode)
	b4		- USA0			- 0  (Fixed Source)
	b5		- UDA0			- 1  (Forward Destination)
	b7:b6	- Reserved		- 00 */	
	
	dmd0 = 0x25;
}
/******************************************************************************
End of function Init_DMA0
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _ad_converter0
* Description 	: Interrupt Handler for ADC
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_ad_converter0(vect=42)
void _ad_converter0(void)
{
	/* Check the DMAC count */ 
	if (dct0 != 0 ) 
	{
		/* ADC conversion start flag. Set to 1 to start ADC conversion */
		adst_ad0con0 = 1;
	}
	else 
	{
		/* ADC conversion start flag. Set to 0 to stop ADC conversion */
		adst_ad0con0 = 0;
	}
}
/******************************************************************************
End of ISR _ad_converter0
******************************************************************************/
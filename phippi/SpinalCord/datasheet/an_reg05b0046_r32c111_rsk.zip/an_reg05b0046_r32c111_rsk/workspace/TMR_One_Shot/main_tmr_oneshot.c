/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_tmr_oneshot.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Initializes Timer TA0 in one-shot mode
*				The timer is started using software start and LED2 is turned on
*				LED2 will be turned off when the one-shot expires after 
*				4.9 milliseconds.
*
* Operation     : 1. Build this application and download it to the target. 
*				  2. Click on the "Reset Go" icon available on 'Debug Run' toolbar.  
*				  3. LED2 will be turned on when oneshot starts & will be turned OFF
*					 when the oneshot expires.
*  				  4. Connect oscilloscope probe at J2-1 to observe a positive pulse
*					 of 4.9 ms duration. 
**********************************************************************************/

/**********************************************************************************
User Includes
***********************************************************************************/
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"	
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include 	"main_tmr_oneshot.h"

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routine for timer 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void main (void)
{ 
	/* Initialise TImer A0 in one shot mode */   
	tmr_init();
		
	/* Turn ON LED2 */
   	LED2 =LED_ON;
	
	/* Start one-shot bit*/
	ta0os = 1;     
	
  	/* This loop will never exit.	*/
	while (1);
}
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: tmr_init
* Description 	: Setup Timer A0 setup for 4.9 ms in one-shot mode.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void tmr_init(void)
{
	/* Enable port TA0OUT pin to provide Timer output */
	p7_0s = 0x01; 
	pd7_0 = 1;
	
	/* Timer a0 mode register
	b1:b0	- TMOD1:TMOD0	- 10 (One shot mode selected)
	b2		- Reserved		- 1  (Set to 0)
	b4:b3	- MR2:MR1		- 0  (Select oneshot flag as trigger)
	b5		- MR3			- 0  (Set to 0)
	b7:b6	- TCK1:TCK0		- 11 (Select fc32 clock source ) */	

    ta0mr = 0xC6 ;	

	/*((32768/ 32)* 0.005)) = 4.9 ms pulse */	 
	ta0 = 5 ; 
	
	/* Disable interrupts  */
 	DISABLE_IRQ		
	
	/* Set interrupt priority level to enable the timer interrupt */
	ta0ic = 0x02;		  	
    
	/* Enable Interrupts */
	ENABLE_IRQ			

	/* Start the timer. */
  	ta0s = 1;
}
/******************************************************************************
End of function tmr_init
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _timer_a0
* Description 	: Timer a0 Interrupt Service Routine. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma INTERRUPT _timer_a0 (vect=12)
void _timer_a0(void)
{
	/* Turn OFF LED2 */
   	LED2 = LED_OFF;
}
/**********************************************************************************
End of ISR _timer_a0
***********************************************************************************/

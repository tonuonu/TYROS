/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: uart.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description   : Contains Transmit/Receive operation functions for 
*					R32C/111 on-chip UART driver. 
*
* Note: This file contains a compiler directive "#pragma interrupt 
* functionname" which instructs the compiler to treat the following 
* function as an interrupt. The compiler will save all registers
* used in the function and replace the normal RTS instruction with an REIT
* instruction at the end of the function.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes
******************************************************************************/
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"	
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "uart.h"
/* Following header file provides macros used in this file */	
#include "main_iic_communication.h"

/******************************************************************************
Global Variables
******************************************************************************/
/* Used to store the received data */
volatile unsigned char U0_in;

/* Used as flag, to be polled for end of user input string */
extern unsigned char end_of_str;

/* Buffer to store user entered characters */
extern unsigned char readBuff[EEPROM_BUFF_LENGTH];

/* This variable stores the size of the string entered by the user on the
   HyperTerminal	*/
volatile unsigned char string_size;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: uart0_init
* Description 	: UART configuration - BAUD - 19200, 8 data bits, 1 stop bit,
*				  no parity.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void uart0_init(void) 
{
	/* Set UART0 bit rate generator bit rate can be calculated by:	
		bit rate = ((BRG count source / 16)/baud rate) - 1
		Baud rate is based on main crystal / PLL */
	u0brg = (f1_CLK_SPEED / 16 / BAUD_RATE) - 1;	
	
	/* UART0 transmit/receive mode register 
	  b2:b0	- SMD2:SMD0	 - 101 (UART mode with character bit 
	  							length is 8 bits selected)
   	  b3	- CKDIR		 - 0 (Internal clock selected)
   	  b4	- STPS		 - 0 (1 Stop bit)
   	  b5	- PRY		 - 0 (No parity used)
   	  b6	- PRYE		 - 0 (No parity used)
  	  b7	- IOPOL		 - 0 (TXD, RXD polarity not inverted) 	*/
	
	u0mr = 0x05;		
	
	/* UART0 transmit/receive control register 0 
	  b1:b0	- CLK01:CLK0 - 00 (f1 clock selected)
   	  b2 	- Reserved 	 - 0 
  	  b3	- TXEPT		 - 0 (Clear transmit register empty flag)
   	  b4	- CRD		 - 1 (Disable CTS/RTS function)
   	  b5	- NCH		 - 0 (Pins TXDi/SDAi and SCLi are push-pull output)
   	  b6	- CKPOL		 - 0 (Transmit data is output at the falling edge of
	  						 transmit/receive clock and receive data is input at
							 the rising edge
  	  b7	- UFORM		 - 0 (LSB first selected) */

  	u0c0 = 0x10; 		

	/* Dummy read of UART0 receive buffer */
	u0tb = u0rb;		
	
	/* Clear UART0 transmit buffer */
  	u0tb = 0;			

	/* Disable interrupts before setting interrupt control register */
    DISABLE_IRQ			
	
	/* Interrupt Control Register for UART0
	b2:b0 	- ILVL2:ILVL0 	- 100 (Interrupt priority 4 selected for UART0)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0.)  
	b5 		- Reserved		- 0
	b7:b6 	- Reserved		- 0 		*/

	s0ric = 0x04;			
	
	/* Enable interrupts */
	ENABLE_IRQ	
	   
	/* Pin settings for making pin p6_3 as transmitter pin of UART0 */
	p6_3s = 0x03;
	
	/* Pin settings for making pin p6_2 as transmitter pin of UART0 */            
	pd6_3 = 1;
 
    /* Pin settings for making pin p6_2 as receiver pin of UART0 */
	pd6_2 = 0;
	
	/* UART0 transmit/receive control register 1 
	b0 		- TE		- 1 (Enable transmission)	
	b1	 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
	b2 		- RE 		- 1 (Enable reception)
	b3 		- RI		- 0 (Clear the 'Receive complete' flag)
	b4 		- U0IRS		- 0 (U0TB register is empty)
	b5		- U0RRM		- 0 (Continuous receive mode disabled)
	b6		- UOLCH		- 0 (Data non logic-inverted)
	b7		- Reserved  - 0 */

	u0c1 = 0x05; 		
}
/******************************************************************************
End of function uart0_init
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: text_write
* Description 	: This function sends a text string to the terminal program  
* Argument  	: (const char *) msg_string -> the text string to output
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void text_write (_far const char * msg_string)
{
	/* Variable used to refer specific data while reading from the message buffer */
	char i;
	
	/* This loop reads a text string from the buffer and loads it to the UART0
	   transmit buffer */
	for (i = 0; msg_string[i]; i++)
	{	 
		while(ti_u0c1 == 0)
		{
			/* Wait till the previous transmission completes */					
		}

		/* Output the character on the serial port. */ 
		u0tb = (short)msg_string[i];
	}
}
/******************************************************************************
End of function text_write
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _uart0_receive
* Description 	: Interrupt handler for UART0 receive
*		   		  Reads character received from keyboard and stores in the 
*				  variable 'U0_in'
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_uart0_receive(vect=18)
void _uart0_receive(void)
{
	static unsigned char cnt = 0;
	
	while(ri_u0c1 == 0)
	{
		/* Make sure that the receive is complete */	
	}

	/* Read the received data */
	readBuff[cnt] = (unsigned char)u0rb;

	/* Check for number of input characters are not greater than 64 */
	if(cnt >= (EEPROM_BUFF_LENGTH - 1))
	{
		/* Send following message if number of input characters are 
		greater than 64 */
		text_write("\r\n>>User Entered string length exceeds 64 bytes");
		text_write("\r\n>>Please re-enter the string\r\n");	
		
		/* Reset the counter to restart accepting new input.	*/
		cnt = 0;
	}
	
	/* Check for 'Enter Key' press event */
	else if (readBuff[cnt] == ENTER_KEY)
	{
		/* If no input is received from user, then ask user to input a string */
		if (cnt == 0) 
		{
			text_write(">>No Input, Please type characters string and press Enter\r\n");
		}
		 
		else 
		{
			/* Store 0x00 as last read character */		
			readBuff[cnt] = 0x00;
			
			/* Stores the string size	*/
			string_size = (cnt+1);
			
			/* Set the flag */
			end_of_str = 1;			

			/* Reset the counter */
			cnt = 0;
		}
	}	
	
	else
	{
		while(ti_u0c1 == 0)
		{
			/* Wait till the previous transmission completes */					
		}

		/* Output the character on the serial port. */ 
		u0tb = (short)readBuff[cnt];		
		
		/* Increment the counter */
		cnt++;
	}
}
/**********************************************************************************
End of ISR _uart0_receive
***********************************************************************************/

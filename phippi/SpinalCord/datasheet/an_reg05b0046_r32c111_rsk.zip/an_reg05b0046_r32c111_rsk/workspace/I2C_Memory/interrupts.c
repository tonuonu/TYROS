/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: interrupts.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Contains interrupts handlers for interrupts used in this
*                 application
*
* Note			: This file includes following  compiler directive - 
*				  #pragma interrupt functionname
* 				  This directive instructs the compiler to treat the following
*                 function as an interrupt. The compiler will save all registers
*				  used in the function and replace the normal REIT instruction 
*				  with an REIT instruction at the end of the function.
* 				  The intprg.c file must be modified to point the appropriate
*				  vector at this function.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/* Following header file provides prototypes for interrupt configuring
   functions */
#include "interrupts.h"

/******************************************************************************
Global variables
******************************************************************************/
/* Transfer flag. This flag sets when transmit or receive interrupt occurs	 */
extern volatile unsigned char trans_flag;
/* Stores the initial values to be written in RTC	*/
extern char rtc_buff[16];
/* This flag indicates that the RTC value needs to be rewritten in the RTC device	*/
extern unsigned char rtc_updated;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _uart2_receive
* Description 	: Interrupt handler for UART2 receive
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_uart2_receive(vect=34)
void _uart2_receive(void)
{
	/* Set the transfer flag to indicate that the transmission is successful	*/
	trans_flag = 1;
	
	/* Clear the interrupt flag	*/
	ir_s2ric = 0;
}
/**********************************************************************************
End of ISR _uart2_receive
***********************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _uart2_trans
* Description 	: Interrupt handler for UART2 transmit
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_uart2_trans(vect=33)
void _uart2_trans(void)
{
	/* Set the transfer flag to indicate that the reception is successful	*/	
	trans_flag = 1;
	
	/* Clear the interrupt flag	*/	
	ir_s2tic = 0;
}
/**********************************************************************************
End of ISR _uart2_trans
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _int0
* Description 	: Interrupt Handler for INT0. SW1 is connected to INT0
*				  interrupt pin
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_int0(vect=31)
void _int0(void)
{
	unsigned char ucDelay = 0xFF;
	
	while (ucDelay--)
	{
		/* Debounce delay */
	}
	
	/* Increment seconds & check for hex character	*/
	if((++rtc_buff[1] & 0x0F) == 0x0A)
	{
		rtc_buff[1] += 6;
	}
	
	/* Reset if it crosses BCD 59 */
	if(rtc_buff[1] > 0x59)
	{
		rtc_buff[1] = 0;
	}
	
	/* Indicate that the RTC value needs an update in the RTC device	*/
	rtc_updated=1;
	
	/* Clear interrupt flag */
	/* Interrupt flags are cleared automatically */
}
/**********************************************************************************
End of ISR _int0
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _int1
* Description 	: Interrupt Handler for INT1. SW2 is connected to INT1
*				  interrupt pin
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_int1(vect=30)
void _int1(void)
{
	unsigned char ucDelay = 0xFF;

	while (ucDelay--)
	{
		/* Debounce delay */
	}

	/* Increment minutes & check for hex character	*/
	if((++rtc_buff[2] & 0x0F) == 0x0A)
	{
		rtc_buff[2] += 6;
	}
	
	/* Reset if it crosses BCD 59 */
	if(rtc_buff[2] > 0x59)
	{
		rtc_buff[2] = 0;
	}

	/* Indicate that the RTC value needs an update in the RTC device	*/		
	rtc_updated=1;
	
	/* Clear interrupt flag */
	/* Interrupt flags are cleared automatically */
}
/**********************************************************************************
End of ISR _int1
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _int2
* Description 	: Interrupt Handler for INT2. SW3 is connected to INT2
*				  interrupt pin
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_int2(vect=29)
void _int2(void)
{
	unsigned char ucDelay = 0xFF;

	while (ucDelay--)
	{
		/* Switch debouncing delay	*/
	}
	
	/* Increment hours & check for hex character	*/
	if((++rtc_buff[3] & 0x0F) == 0x0A)
	{
		rtc_buff[3] += 6;
	}
	
	/* Reset if it crosses BCD 23 */
	if(rtc_buff[3] > 0x23)
	{
		rtc_buff[3] = 0;
	}	

	/* Indicate that the RTC value needs an update in the RTC device	*/		
	rtc_updated=1;

	/* Clear interrupt flag */
	/* Interrupt flags are cleared automatically */
}
/**********************************************************************************
End of ISR _int2
***********************************************************************************/

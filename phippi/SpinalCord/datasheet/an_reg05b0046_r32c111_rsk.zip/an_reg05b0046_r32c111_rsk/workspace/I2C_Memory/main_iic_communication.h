/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_iic_communication.h
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Header file for main program
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

#ifndef MAIN_IIC_COMMUNICATION_H
#define MAIN_IIC_COMMUNICATION_H

/******************************************************************************
Macro Defines
******************************************************************************/
#define EEPROM_BUFF_LENGTH	64
#define RTC_READ			0xD1
#define RTC_WRITE			0xD0
#define EEPROM_READ			0xA1
#define EEPROM_WRITE		0xA0
#define WRITE				1
#define READ				0
#define ENTER_KEY			0x0d
#define TIMEOUT_CNT 		0xffffu
#define DELAY_CNT 			0xff
#define TIMEOUT_ERROR 		0
#define BIT_RATE			100000	

/******************************************************************************
Function Prototypes
******************************************************************************/
void main(void);   
void Init_IIC(void);
void setStart_Condition(void);
void setStop_Condition(void);
char IIC_Rx_data(unsigned char *data, unsigned char numBytes, 
	unsigned char device_id);
char IIC_Tx_Byte(unsigned char data);
char IIC_Transfer(unsigned char RW, unsigned char numBytes,
	unsigned char *data, unsigned long DeviceMem_Addr, 
	unsigned char device_id);
void delay(unsigned long delayCnt);
void send_error_message(void);
void Convert_time_ToASCII(unsigned char* buffer);

#endif 	

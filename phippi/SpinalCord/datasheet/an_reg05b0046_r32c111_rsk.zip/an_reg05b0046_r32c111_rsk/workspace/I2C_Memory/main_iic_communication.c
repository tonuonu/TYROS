/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_iic_communication.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: This program demonstrates the configuration of uart2 in
*				  spcial mode 1 (IIC) to communicate with IIC eeprom on the 
*				  application board. User enters a string on the terminal
*				  window which will be written to the IIC EEPROM. The
*				  application then further reads it back from the EEPROM & displays
*				  back to the terminal window. The size of string is limited up to 
*				  64 bytes. At the same time the application also reads the RTC
*				  available on the application board. The time can be set using the
*				  switches on the RSK. 		
*
* Operation     : 1. Connect PC and RSKR32C111 using standard RS232 cable.
*				  2. Make following connections between RSKR32C111 and General 
*					 application board.
*						----------------------------------------------------
*						RSKR32C111						General App. Board
*						----------------------------------------------------
*						a. JA1-25 (IIC_SDA) 	-->		JA1-25 (SDA)
*						b. JA1-26 (IIC_SCL)		-->		JA1-26 (SCL)
*						c. JA1-1  (VCC)			-->		JA1-1 (CON_5V)
*						d. JA1-2  (GND)			-->		JA1-2 (GND)					
*				  3. Run a terminal application (such as HyperTerminal) on the PC
*			 		 with the following settings - 
*						Baud rate 19200, 8 data bits, 1 stop bit,  no parity.
*				  4. Build this application and download it to the target. 
*				  5. Click on the "Reset Go" icon available on 'Debug' toolbar.  
*				  6. Welcome message will be shown on the terminal window.
*  				  7. Type a string (up to 64 characters) and press 'Enter'.
* 				  8. The entered string will be written to the EEPROM, read back 
*					 from the EEPROM & will be displayed on the terminal window.
*				  9. The application will also read the time from RTC & show it
*					 on the debug LCD. 
*				  10.The time can be changed using SW1, SW2 & SW3 on the RSKR32C111.
*				  11.Use the switches as follows -
*					 a. press SW1 to increment the seconds by 1.
*					 b. press SW2 to increment the minutes by 1.
*					 c. press SW3 to increment the hours by 1.
* 
* Note : 
*	1. This code uses I2C Page write to copy data on to the EEPROM. 
*	   The writing address will roll over at the end of first page to
*	   the start of the same page. 
*      The EEPROM used to test this sample code is from "Renesas" and
*	   the Part number is "HN58X24512I".The page size of the mentioned
*	   EEPROM is 128 bytes.
*      This code will not work if user is using EEPROM with a Page size
* 	   less than 64 bytes.
* 	2. This file includes following  compiler directive - 
*	   #pragma interrupt functionname
* 	   This directive instructs the compiler to treat the following
*      function as an interrupt. The compiler will save all registers
*	   used in the function and replace the normal REIT instruction 
*	   with an REIT instruction at the end of the function.
* 	   The intprg.c file must be modified to point the appropriate
*	   vector at this function.

******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main_iic_communication.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides prototypes for the functions used in this
	file.	*/
#include "uart.h"
/*	Following header file provides useful macros and function prototypes for
	controlling the LCD interface.	*/
#include	"lcd.h"

/*******************************************************************************
Constants
*******************************************************************************/
/* String constants used for screen output far since they are outside 64k boundary */
_far const char cmd_clr_scr[] = {27,'[','2','J',0};
_far const char cmd_cur_home[] = {27,'[','H',0};

/******************************************************************************
Global variables
******************************************************************************/
/* Buffer to store characters entered by user, also it is used to send 
them back */
unsigned char readBuff[EEPROM_BUFF_LENGTH];
/* Buffer to store characters received from EEPROM */
unsigned char recBuff[EEPROM_BUFF_LENGTH];
/* Used as flag, to be polled for end of user input string */
unsigned char end_of_str = 0;
/* Transfer flag. This flag sets when transmit or receive interrupt occurs	 */
volatile unsigned char trans_flag=0;
/* This variable stores the size of the string entered by the user on the HyperTerminal	*/
extern volatile unsigned char string_size;
/* This flag indicates that the RTC value needs to be rewritten in the RTC device	*/
unsigned char rtc_updated=1;
/* Stores the initial values to be written in RTC	*/
unsigned char rtc_buff[16] = { 0x00,0x00,0x00,0x00,0x01,0x01,0x08,0x00,
  0x00,0x01,0x01,0x00,0x00,0x00,0x00,0x00 };
/* Stores the time in character format to display on the debug LCD	*/
char dBuff_time [9];

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routine for IIC and 
				  UART 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void main(void)		
{
	/* Device memory address */
	unsigned long memAddr = 0x00;
	
	/* Loop counter */
	unsigned char loopCnt;
	
	/* Delay counter */
	unsigned short delayCnt = DELAY_CNT;

	/* Initializes the debug LCD module */
	InitialiseDisplay();
	
	/* Display "I2C RTC" message on debug LCD Line 1 */
	DisplayString(LCD_LINE1, "I2C RTC ");		
	
	/* Initializes the uart module */
	uart0_init();
	
	/* SW1 connected to INT0n and configured as follows 
	Interrupt Control Register for INT0 
	b2:b0 	- ILVL2:ILVL0 	- 110 (Interrupt priority 6 selected for INT0)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Falling edge selected.)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	int0ic = 0x06;

	/* SW2 connected to INT1n and configured as follows 
	Interrupt Control Register for INT1
	b2:b0 	- ILVL2:ILVL0 	- 101 (Interrupt priority 5 selected for INT1)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Falling edge selected.)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	int1ic = 0x05;

	/* SW3 connected to INT2n and configured as follows 
	Interrupt Control Register for INT2
	b2:b0 	- ILVL2:ILVL0 	- 100 (Interrupt priority 4 selected for INT2)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Falling edge selected.)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	int2ic = 0x04;

	/* Enable interrupts by setting i flag */
	ENABLE_IRQ		
	
	/* Initializes the IIC module */
	Init_IIC();
		
	/* Write welcome messages to PC terminal */ 	
	text_write(cmd_clr_scr);	 	
	text_write(cmd_cur_home);
	text_write(">>Renesas RSKR32C111 IIC_COM demonstration\r\n");
	text_write(">>Please type character string and press Enter\r\n");
	text_write(">>This string will be written into IIC memory\r\n");
	text_write(">>then read and sent back to terminal...\r\n");
	text_write(">>PS: please do not write more than 64 characters\r\n");
	
	while (1)
	{
		/* Check for end of string before writing to the EEPROM	*/
		if(end_of_str)
		{
			/* Transfer string from buffer to IIC EEPROM */
			if (IIC_Transfer(WRITE, string_size,
				readBuff, memAddr, EEPROM_WRITE) == TIMEOUT_ERROR)
			{
				/* Display error message to PC terminal */
				send_error_message();
			}
			
			/* Clear the buffer after writing data to EEPROM	*/
			for(loopCnt=0; loopCnt<EEPROM_BUFF_LENGTH; loopCnt++)
			{
				/* Clear the send/receive buffer by writing zeros */	
				readBuff[loopCnt]=0x00;
			}
			
			/* Delay in between transmit and receive operation */
			delay(delayCnt);
		
			/* Write message to PC terminal */
			text_write("\r\n>>Reading from FLASH...\r\n");
		
			/* Transfer string from IIC EEPROM to buffer */
			if (IIC_Transfer(READ, EEPROM_BUFF_LENGTH, 
					recBuff, memAddr, EEPROM_READ) == TIMEOUT_ERROR)
			{
				/* Send the error message to PC terminal */
				send_error_message();
			}
		
			/* Send message to PC terminal */
			text_write(">>The entered string is: \r\n");
		
			/* Send the content of the buffer read from IIC EEPROM  */
			text_write((char *)recBuff);
		
			/* Send message to PC terminal */
			text_write("\r\n>>Please, enter again...\r\n");
		
			/* Clear end of string flag */
			end_of_str = 0;
		}
		
		if(rtc_updated == 1)
		{
			/* Set the RTC time to 00:00:00 */
			if (IIC_Transfer(WRITE, (sizeof(rtc_buff)/2),
				rtc_buff, memAddr, RTC_WRITE) == TIMEOUT_ERROR)
			{
				/* Display error message to PC terminal */
				send_error_message();
			}	

			/*  Start the RTC */
			if (IIC_Transfer(WRITE, 0x01,
				&rtc_buff[0x0C], 0x0c, RTC_WRITE) == TIMEOUT_ERROR)
			{
				/* Display error message to PC terminal */
				send_error_message();
			}	
		
			/* Clear the flag after writing the updated value of RTC	*/
			rtc_updated	= 0;
		}

		else
		{
			/* Read the RTC time */
			if (IIC_Transfer(READ, sizeof(rtc_buff), 
					rtc_buff, memAddr, RTC_READ) == TIMEOUT_ERROR)
			{
				/* Send the error message to PC terminal */
				send_error_message();
			}						
		}
		
		/* Convert the time in form of characters to display on LCD	*/
		Convert_time_ToASCII(rtc_buff);
		
		/* Display RTC time on debug LCD */
		DisplayString(LCD_LINE2, dBuff_time);		
	}
}         
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: Init_IIC
* Description 	: Configuration of IIC module with 100kbps bit rate.  
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void Init_IIC(void)
{
	/* UART2 transmit/receive mode register 
	  b2:b0	- SMD2:SMD0	 - 010 (IIC mode)
   	  b3	- CKDIR		 - 0 (Internal clock selected)
   	  b4	- STPS		 - 0 (Not applicable in IIC mode)
   	  b5	- PRY		 - 0 (Not applicable in IIC mode)
   	  b6	- PRYE		 - 0 (Not applicable in IIC mode)
  	  b7	- IOPOL		 - 0 (TXD, RXD polarity not inverted) 	*/
	  
	u2mr = 0x02;
	
	/* Set UART2 bit rate generator bit rate can be calculated as follows:	
	bit rate = ((BRG count source / 16)/baud rate) - 1
	Baud rate is based on main crystal / PLL 
	IIC is Configured with a bit rate of 100K */
	
	u2brg = (((f1_CLK_SPEED/8)/2)/BIT_RATE)-1;
	
	/* UART2 transmit/receive control register 0 
	  b1:b0	- CLK01:CLK0 - 01 (U0BRG count source select bits -f8 selected)
	  b2 	- Reserved 	 - 0 
	  b3	- TXEPT		 - 0 (Clear transmit register empty flag)
	  b4	- CRD		 - 1 (Disable CTS/RTS function)
	  b5	- NCH		 - 1 (Pins TXDi/SDAi and SCLi are Nchannel
							  open drain output)
	  b6	- CKPOL		 - 0 (Output transmit data on the falling
							  edge of the transmit/receive clock
							  and input receive data on the rising edge.)
  	  b7	- UFORM		 - 1 (MSB first selected) */
	  
	u2c0 = 0xb1;

	/* UART2 Special Mode Register. I2C mode selected */ 	
	u2smr = 0x01;

	/* UART2 Special Mode Register 2
	  b0	- IICM2 	 - 0 (Use NACK/ACK interrupt)
	  b1 	- CSC 		 - 1 (Clock synchronization enabled)
	  b2	- SWC		 - 0 (No wait/Wait cleared)
	  b3	- ALS		 - 0 (Do not stop the SDA output)
	  b4	- STC		 - 0 (Do not initialize the circuit)
	  b5	- SWC2		 - 0 (Output the transmit/receive clock
	  						  at the SCL pin)
  	  b6	- SDHI		 - 0 (Output data)
	  b7	- Reserved	 - 0 */ 
	  	
	u2smr2 = 0x02;

	/* UART2 Special Mode Register 3
	   b0	  - SSE			- 0 (SS disabled)
	   b1	  - CKPH 		- 0 (No delayed clock)
	   b2	  - DINC		- 0 (Select the TXDi/RXDi pin (master mode))
	   b3	  - NODC 		- 0 (The CLKi pin is push-pull output)
	   b4 	  - ERR			- 0 (No error detected)
	   b7:b5  - DL2:DL0 	- 000 (No delay) */
	   	
	u2smr3 = 0x00;
	
	/* UART2 Special Mode Register 4
	   b0	  -	STAREQ		- 0 (Clear Start Condition Generate bit)
	   b1	  -	RSTAREQ 	- 0 (Clear Restart Condition Generate bit)
	   b2	  -	STPREQ		- 0 (Clear Stop Condition Generate bit)
	   b3	  -	STSPSEL 	- 0 (start/stop condition generate circuit)
	   b4     -	ACKD		- 0 (Clear data output)
	   b5  	  -	ACKC		- 1 (ACK Data Output)
	   b6	  - SCLHI		- 0 (Do not stop SCLi output)
	   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
	   	
	u2smr4 = 0x20;

	/* UART2 transmit/receive control register 1 
   	  b0 	- TE		- 1 (Enable transmission)	
	  b1 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
	  b2 	- RE 		- 1 (Enable reception)
	  b3 	- RI		- 0 (Clear the 'Receive complete' flag)
	  b4 	- UiIRS     - 0 (U2TB register is empty)
	  b5	- UiRRM		- 0 (Continuous receive mode disabled)
	  b6	- Reserved	- 0 (Data non logic-inverted)
	  b7	- Reserved	- 0 */
	  	
	u2c1 = 0x05;
	
	/* Enabled the port pins p7_0 & p7_1 as I2C SDA & SCL pins respectively */
	p7_0s = 0x03; 
	p7_1s = 0x03; 	
	pd7_0 = 1; 
	pd7_1 = 1; 	

	/* Disable Interrupts	*/
	DISABLE_IRQ

	/* Interrupt Control Register for UART2 transmit
	b2:b0 	- ILVL2:ILVL0 	- 011 (Interrupt priority 3 selected for UART2
								   transmit)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Set to 0.)  
	b5 		- Reserved		- 0
	b7:b6 	- Reserved		- 0 		*/
		
	s2tic = 0x03;

	/* Interrupt Control Register for UART2 receive
	b2:b0 	- ILVL2:ILVL0 	- 100 (Interrupt priority 4 selected for UART2
								   transmit)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0.)  
	b5 		- Reserved		- 0
	b7:b6 	- Reserved		- 0 		*/
	
	s2ric = 0x02;
	
	/* Enable interrupts */
	ENABLE_IRQ
}
/******************************************************************************
End of function Init_IIC
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: setStart_Condition
* Description 	: Configuration of IIC start condition 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void setStart_Condition(void)
{
	/* UART2 Special Mode Register 4
	   b0	  -	STAREQ		- 1 (Start Condition Generate bit)
	   b1	  -	RSTAREQ 	- 0 (Clear Restart Condition Generate bit)
	   b2	  -	STPREQ		- 0 (Clear Stop Condition Generate bit)
	   b3	  -	STSPSEL 	- 0 (start/stop condition generate circuit)
	   b4     -	ACKD		- 1 (Set NACK)
	   b5  	  -	ACKC		- 1 (ACK Data Output)
	   b6	  - SCLHI		- 1 (Do not stop SCLi output)
	   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */		   
	
	u2smr4 = 0x71;
	
	/* Delay	*/
	delay(1000);

	/* UART2 Special Mode Register 4
	   b0	  -	STAREQ		- 1 (Start Condition Generate bit)
	   b1	  -	RSTAREQ 	- 0 (Clear Restart Condition Generate bit)
	   b2	  -	STPREQ		- 0 (Clear Stop Condition Generate bit)
	   b3	  -	STSPSEL 	- 1 (start/stop condition generate circuit)
	   b4     -	ACKD		- 0 (Clear data output)
	   b5  	  -	ACKC		- 0 (ACK Data Output)
	   b6	  - SCLHI		- 0 (Do not stop SCLi output)
	   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
	   
	u2smr4 = 0x09;	 
	
	/* Delay	*/	
	delay(1000);
	
	while (ir_bcn2ic == 0)
	{
		/* Wait till start condition interrupt is generated */
	}
	
	/* Reset the flag by software */
	ir_bcn2ic = 0;
}
/******************************************************************************
End of function setStart_Condition
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: setStop_Condition
* Description 	: Configuration of IIC stop condition 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void setStop_Condition(void)
{
	/* UART2 Special Mode Register 4
	   b0	  -	STAREQ		- 0 (Clear Start Condition Generate bit)
	   b1	  -	RSTAREQ 	- 0 (Clear Restart Condition Generate bit)
	   b2	  -	STPREQ		- 1 (Set Stop Condition Generate bit)
	   b3	  -	STSPSEL 	- 0 (start/stop condition generate circuit)
	   b4     -	ACKD		- 1 (Set data output)
	   b5  	  -	ACKC		- 1 (ACK Data Output)
	   b6	  - SCLHI		- 1 (Do not stop SCLi output)
	   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
	   
	u2smr4 = 0x74;
	
	/* UART2 Special Mode Register 4
	   b0	  -	STAREQ		- 0 (Clear Start Condition Generate bit)
	   b1	  -	RSTAREQ 	- 0 (Clear Restart Condition Generate bit)
	   b2	  -	STPREQ		- 1 (Set Stop Condition Generate bit)
	   b3	  -	STSPSEL 	- 1 (start/stop condition generate circuit)
	   b4     -	ACKD		- 0 (Clear data output)
	   b5  	  -	ACKC		- 0 (Disable ACK Data Output)
	   b6	  - SCLHI		- 0 (Do not stop SCLi output)
	   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
	   
	u2smr4 = 0x0C;	 
	
	/* Transmission enabled*/
	te_u2c1 = 1;
	
	while (ir_bcn2ic == 0)
	{
		/* Wait till start condition interrupt is generated */
	}
	
	/* Reset the flag by software */
	ir_bcn2ic = 0;
}
/******************************************************************************
End of function setStop_Condition
******************************************************************************/
	
/*��FUNC COMMENT��**************************************************************
* Outline 		: IIC_Transfer
* Description 	: Configuration of IIC to transmit/receive data 
* Argument  	: (unsigned char) RW - read/write mode of operation;
*				  (unsigned char) numBytes - number of bytes to be transmitted/
*				   received;
*				  (unsigned char *) data - data to be transmitted/received;
*				  (unsigned long)DeviceMem_Addr - device start of operation 
*				   address 
*				  (unsigned char) device_id	- Device ID
* Return value  : (char) - 1 = success, 0 = failure
*��FUNC COMMENT END��**********************************************************/

char IIC_Transfer(unsigned char RW, unsigned char numBytes,
			unsigned char *data, unsigned long DeviceMem_Addr, unsigned char device_id)
{
	/* Delay Counter */
	unsigned short delayCnt = DELAY_CNT;
	
	/* EEPROM address location variables */
	unsigned char *addr_ptr, AddrH, AddrL; 
	
	/* Loop counter variable */
	unsigned char loopCnt;

	/* Stores return value	*/
	char ret_value = 1;	
	
	/* Pointer to EEPPROM memory locations */
	addr_ptr = (unsigned char *)&DeviceMem_Addr;
	
	/* MSB of address */
	AddrH = *addr_ptr++;
	
	/* LSB of address */
	AddrL = *addr_ptr;
	
	/* Generate start condition */
	setStart_Condition();
		
	/* Transmit EEPROM device ID */
	if(IIC_Tx_Byte((device_id & 0xFE)) == TIMEOUT_ERROR) 
	{
		/* If error in transmission operation, return TIMEOUT_ERROR */
		ret_value = TIMEOUT_ERROR;
	}
	
	/* Transmit MSB EEPROM memory address */
	if(IIC_Tx_Byte(AddrH) == TIMEOUT_ERROR) 
	{
		/* If error in transmission operation, return TIMEOUT_ERROR */
		ret_value = TIMEOUT_ERROR;
	}
	
	if(ret_value != TIMEOUT_ERROR)
	{
		if((device_id & 0xFE) == EEPROM_WRITE)
		{
			/* LSB EEPROM memory address data transmit */
			if(IIC_Tx_Byte(AddrL) == TIMEOUT_ERROR) 
			{
				/* If error in transmission operation, return TIMEOUT_ERROR */
				ret_value = TIMEOUT_ERROR;
			}
		}
		
		if(ret_value != TIMEOUT_ERROR)
		{
			if(RW == READ)
			{
				/* UART2 Special Mode Register 4
				   b0	  -	STAREQ		- 0 (Clear Start Condition Generate bit)
				   b1	  -	RSTAREQ 	- 1 (Set Restart Condition Generate bit)
				   b2	  -	STPREQ		- 0 (Clear Stop Condition Generate bit)
				   b3	  -	STSPSEL 	- 0 (start/stop condition generate circuit)
				   b4     -	ACKD		- 1 (Set data output)
				   b5  	  -	ACKC		- 1 (ACK Data Output)
				   b6	  - SCLHI		- 1 (Do not stop SCLi output)
				   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
			   
				u2smr4 = 0x72;
	
				/* Delay	*/
				delay(1000);
	
				/* UART2 Special Mode Register 4
				   b0	  -	STAREQ		- 0 (Clear Start Condition Generate bit)
				   b1	  -	RSTAREQ 	- 1 (Set Restart Condition Generate bit)
				   b2	  -	STPREQ		- 0 (Clear Stop Condition Generate bit)
				   b3	  -	STSPSEL 	- 1 (start/stop condition generate circuit)
				   b4     -	ACKD		- 0 (Clear data output)
				   b5  	  -	ACKC		- 0 (Disable ACK Data Output)
				   b6	  - SCLHI		- 0 (Do not stop SCLi output)
				   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
	   
				u2smr4 = 0x0A;	 
	
				/* Delay	*/				
				delay(1000);
				
				/* Low is output at the SCL pin after 9th bit
				   is received, this is required for sending ACK*/
				swc9_u2smr4 = 1;				
			
				/* For Read mode, transmit Slave_Addr again + Read mode bit */
				if(IIC_Tx_Byte((device_id | 0x01)) == TIMEOUT_ERROR) 
				{
					/* If error in transmission operation, return TIMEOUT_ERROR */
					ret_value = TIMEOUT_ERROR;
				}
						
				/* Receive string from EEPROM */
				if (IIC_Rx_data(data, numBytes, device_id) == TIMEOUT_ERROR) 
				{
					/* If error in reception operation, return TIMEOUT_ERROR */
					ret_value = TIMEOUT_ERROR;
				}
			}
			
			else
			{
				/* Write buffer to EEPROM */
				for (loopCnt=0; loopCnt<numBytes; loopCnt++)
				{
					if (IIC_Tx_Byte(*data) == TIMEOUT_ERROR) 
					{
						/* If error in transmission operation, return TIMEOUT_ERROR */
						ret_value = TIMEOUT_ERROR;
						break;
					}
					
					/* Next data to write */
					data++;
				}
			}

			if(ret_value != TIMEOUT_ERROR)	
			{
				/* Generate stop condition */
				setStop_Condition();
				
				/* Delay routine for setup/hold time */
				delay(delayCnt);
			}
		}	
	}
	
	/* Return the result */
	return ret_value;
}
/******************************************************************************
End of function IIC_Transfer
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: IIC_Rx_data
* Description 	: IIC receive data routine
* Argument  	: (unsigned char *) data - data to be received;
*				  (unsigned char) numBytes - number of bytes received
*				  unsigned char device_id - device address
* Return value  : (char) - 1 = success, 0 = failure
*��FUNC COMMENT END��**********************************************************/

char IIC_Rx_data(unsigned char *data, unsigned char numBytes, unsigned char device_id)
{
	/* Delay counter */
	unsigned char byte_cnt=0;
	
	/* Flag indicates that the data read operation is complete	*/
	unsigned char complete_transfer=0;
	
	/* Stores return value	*/
	char ret_value = 1;	
	
	/* Temporary varibale to keep track of number of bytes read from I2C device	*/
	unsigned short temp;
	
	/* UART2 Special Mode Register 4
	   b0	  -	STAREQ		- 0 (Clear Start Condition Generate bit)
	   b1	  -	RSTAREQ 	- 0 (Clear Restart Condition Generate bit)
	   b2	  -	STPREQ		- 0 (Clear Stop Condition Generate bit)
	   b3	  -	STSPSEL 	- 0 (start/stop condition generate circuit)
	   b4     -	ACKD		- 1 (Set data output)
	   b5  	  -	ACKC		- 0 (Disable ACK Data Output)
	   b6	  - SCLHI		- 0 (Do not stop SCLi output)
	   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
	   
	u2smr4 = 0x10;
		
	/* Read the data from I2C device	*/
	do
	{	
		/* Store received data */
		*data = (unsigned char)u2rb;
		
		/* UART2 transmit/receive control register 1 
	   	  b0 	- TE		- 1 (Enable transmission)	
		  b1 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
		  b2 	- RE 		- 1 (Enable reception)
		  b3 	- RI		- 0 (Clear the 'Receive complete' flag)
		  b4 	- UiIRS     - 1 (Transmission completed)
		  b5	- UiRRM		- 0 (Continuous receive mode disabled)
		  b6	- Reserved	- 0 (Data non logic-inverted)
		  b7	- Reserved	- 0 */
	  
		u2c1 = 0x15;	
		
		while(ti_u2c1 == 0)
		{
			/* Wait for previous transmission to complete */
		}	 		

		/* Dummy write containing ACK bit to be sent*/
		u2tb = 0x00FF;		

		/* Wait for transmit/receive flag to be set */
		while(trans_flag == 0)
		{
		}

		/* Delay	*/	
		delay(1000);
	
		/* Reset the flag by software */
		*data = (unsigned char)u2rb;

		/* Copy the data from read register	 */
		temp = *data;

		/* Increment the pointer to the read buffer	*/
		data++;
	
		/* If the I2C device is RTC then read only 4 bytes	*/
		if(device_id == RTC_READ)
		{
			if(++byte_cnt > 2)
			{
				/* Set the NACK bit to stop the transfer after receiving last byte	*/
				complete_transfer++;
				ackc_u2smr4 = 1;
			}
		}
		
		/* If the I2C device is EEPROM then read required no. of bytes	*/
		else 
		{
			if(temp == 0)
			{
				/* Set the NACK bit to stop the transfer after receiving last byte	*/			
				complete_transfer++;
				ackc_u2smr4 = 1;
			}
		}
	}
	while((complete_transfer < 2) && (--numBytes));
	
	/* Return the result of the read operation	*/
	return ret_value;
}
/******************************************************************************
End of function IIC_Rx_data
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: IIC_Tx_Byte
* Description 	: IIC Transmit data routine
* Argument  	: (unsigned char) data - Byte to be transmitted
* Return value  : (char) - return value
*��FUNC COMMENT END��**********************************************************/

char IIC_Tx_Byte(unsigned char data)
{
	/* Stores return value	*/
	char ret_value = 1;
	
	/* Temporary varibale to store the data alongwith the dummy ACK bit	*/
	unsigned short temp;
	
	/* Clock delayed function enable	*/
	ckph_u2smr3 = 1;

	/* UART2 Special Mode Register 4
	   b0	  -	STAREQ		- 0 (Clear Start Condition Generate bit)
	   b1	  -	RSTAREQ 	- 0 (Clear Restart Condition Generate bit)
	   b2	  -	STPREQ		- 0 (Clear Stop Condition Generate bit)
	   b3	  -	STSPSEL 	- 0 (start/stop condition generate circuit)
	   b4     -	ACKD		- 0 (Clear data output)
	   b5  	  -	ACKC		- 0 (Disable ACK Data Output)
	   b6	  - SCLHI		- 0 (Do not stop SCLi output)
	   b7	  - SWC9		- 0 (No wait-state/Exit wait-state) */	
	
	u2smr4 = 0x00;
	
	/* Delay	*/
	delay(1000);
	
	while(ti_u2c1 == 0)
	{
		/* Wait for previous transmission to complete */
	}	 		

	/* Store the data to be transmitted	*/
	temp = (unsigned short) data;
	
	/* Store the dummy ACK bit	*/
	temp |= 0x0100;
	
	/* Clear the transfer flag before transmitting data	*/
	trans_flag = 0;
	
	/* Transmit the data to the I2C device */
	u2tb = (short)temp ;
	
	/* Clear the status flags	*/
	u2rb = 0x00;
			
	/* Wait here till the transmit interrupt generates 	*/
	while(trans_flag == 0)
	{
	}
	
	/* Return the result	*/
	return ret_value;			
}
/******************************************************************************
End of function IIC_Tx_Byte
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: delay
* Description 	: Delay routine
* Argument  	: (unsigned long) delayCnt - delay counter 
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void delay(unsigned long delayCnt)
{
	while (delayCnt--)
	{
		/* wait till delay count elapses */
	}
}
/******************************************************************************
End of function delay
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: send_error_message
* Description 	: send the error messages and stop the IIC operation
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void send_error_message(void)
{
	/* Write text to PC terminal */
	text_write(">>Connection to IIC EEPROM is inaccessible or unstable...\r\n");
	text_write(">>Check for connections and restart this application...\r\n");
	
	while(1)
	{
		/* This loop will never exit */
	}
}
/******************************************************************************
End of function send_error_message
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: Convert_time_ToASCII
* Description 	: This function converts the received time to characters.
* Argument  	: (char *) buffer - buffer to store the converted characters
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void Convert_time_ToASCII(unsigned char* buffer)
{
	unsigned char j, i=0;
	
	/* Convert time in string format */
	for (j = 3;j > 0;j--)
	{
		/* Convert the time in ASCII	*/
		dBuff_time[i++] = (char)(buffer[j] >> 4) + 0x30;
		dBuff_time[i++] = (char)(buffer[j] & 0x0F) + 0x30;
		
		/* Add a separator or null if the string completes	*/
		if(i < 8)
		{
			dBuff_time[i++] = ':';
		}

		else
		{
			dBuff_time[i++] = '\0';
		}
	}
}
/**********************************************************************************
End of function Convert_time_ToASCII
***********************************************************************************/

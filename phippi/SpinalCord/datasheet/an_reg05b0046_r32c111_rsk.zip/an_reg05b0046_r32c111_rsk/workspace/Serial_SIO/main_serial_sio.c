/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_serial_sio.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Demonstration of R32C111 on-chip synchronous serial interface
*
* Operation: 	1. Make the following connections on RSKR32C111 -
*			  		a. JA2-6 (or J2-8) [TxD0, p6_3] -> JA1-8 (or J4-36) [RxD4, p9_7] 
*					b. JA2-8 (or J2-9) [RxD0, p6_2] -> JA5-7 (or J1-1) [TxD4, p7_0]  
*					c. JA2-10 (or J2-10) [CLK0, p6_1] -> JA5-8 (or J1-2) [CLK4, p7_2] 
*			    2. Build this application and download it to the target.
*			    3. Click on the "Reset Go" icon available on 'Debug' toolbar.
*				4. The debug LCD will display the message "SSI-COMM".
*				5. A string "Renesas" will be transmitted from UART0
*				   to UART4.
*				6. The string received by UART4 will be displayed on the
*				   debug LCD.
*				7. The user can also examine the string received by UART4 in
*				   the variable "c_RecBuff" using HEW C watch window.
*  Note: This file contains a compiler directive "#pragma interrupt 
*  functionname" which instructs the compiler to treat the following 
*  function as an interrupt. The compiler will save all registers
*  used in the function and replace the normal RTS instruction with an REIT
*  instruction at the end of the function.
*
******************************************************************************/

/******************************************************************************
* History 		: 24.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides useful macros and function prototypes for
	controling the LCD interface.	*/
#include "lcd.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main_serial_sio.h"

/*******************************************************************************
Constants
*******************************************************************************/
/* Constant data to be transmitted	*/
const char c_data[8] = "Renesas";

/*******************************************************************************
Global Variables
*******************************************************************************/
/* Buffer to store the received data	*/
volatile char c_RecBuff[8];

/*******************************************************************************
User Program Code
*******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routines for debug LCD,
				  UART0 and UART4. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void main(void)				
{
	/* Used as a loop counter	*/
	unsigned char loop_cnt;
	
	/* Used to generate delay	*/
	unsigned short dly;

	/* Reset the LCD module */
	InitialiseDisplay();

	/* Display Renesas Splash Screen */
	DisplayString(LCD_LINE1,APP_NAME);
	
	/* Configure UART0 for transmission	*/
	uart0_init();
	
	/* Configure UART4 for reception	*/
	uart4_init();
	
	/* Enable interrupts	*/
	ENABLE_IRQ

	/* This loop transmits all characters contained in the 'c_data' buffer 	*/
	for (loop_cnt=0; loop_cnt<sizeof(c_data); loop_cnt++)
	{
		while(ti_u0c1 == 0)
		{
			/* Wait for previous transmission to complete */
		}	 		 

 		/* Load the data to be transmitted, in the transmit buffer */
		u0tb = (short) c_data[loop_cnt];

		for (dly=0xffffU; dly>0; dly--)
		{
			/* Delay */			  		
		} 
	}

	/*	Display the received string on the second line of the debug LCD. */
	DisplayString(LCD_LINE2,c_RecBuff);

	/* This loop should never exit.	*/
	while (1);
}         
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: uart0_init
* Description 	: Configures UART0 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void uart0_init(void) 
{
	/* Port pin configuration */
	/* Configure the port pin p6_1 (CLK0) as output.	*/
	pd6_1 = 1;
	p6_1s = 0x03;
	
	/* Configure the port pin p6_3 (TXD0) as output.	*/	
	pd6_3 = 1;
	p6_3s = 0x03;
	
	/* Configure the port pin p6_2 (RXD0) as input.	*/
	pd6_2 = 0;
	
	/* Set uart0 clock bit rate */
	u0brg = (unsigned char)(((f1_CLK_SPEED/2)/(BIT_RATE))-1);

	/* UART0 transmit/receive mode register 
	  b2:b0	- SMD12:SMD1 - 001 (Synchronous Serial Mode selected)
   	  b3	- CKDIR		 - 0 (Internal clock selected)
   	  b4	- STPS		 - 0 (1 Stop bit)
   	  b5	- PRY		 - 0 (No parity used)
   	  b6	- PRYE		 - 0 (No parity used)
  	  b7	- IOPOL		 - 0 (TXD, RXD polarity not inverted) 	*/
		
	u0mr = 0x01;
	   
	/* UART0 transmit/receive control register 0 
	  b1:b0	- CLK01:CLK0 - 0 (f1 clock source selected)
   	  b2 	- CRS 		 - 0 (CTS/RTS function select bit (Set to 0))
  	  b3	- TXEPT		 - 0 (Clear transmit register empty flag)
   	  b4	- CRD		 - 1 (Disable CTS/RTS function)
   	  b5	- NCH		 - 0 (CMOS Data output selected)
   	  b6	- CKPOL		 - 1 (Transmit data is output at the rising edge of
	  						  transmit/receive clock and receive data is input at
							  the falling edge.
  	  b7	- UFORM		 - 1 (MSB first selected) */
		
  	u0c0 = 0xd0; 		

	/* UART0 transmit/receive control register 1 
	b0 		- TE		- 1 (Enable transmission)	
	b1	 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
	b2 		- RE 		- 1 (Enable reception)
	b3 		- RI		- 0 (Clear the 'Receive complete' flag)
	b5:b4 	- Reserved  - 0 
	b6		- UOLCH		- 0 (non-inverse data logic selected)
	b7		- UOERE		- 0 (Error signal output disable) */
		
  	u0c1 = 0x05; 	

	/* Unused in synchronous serial mode. Set to 0.	*/
	u0smr = 0x00;

	/* Unused in synchronous serial mode. Set to 0.	*/	
	u0smr2 = 0x00;

	/* UART0 Special Mode Register 3
	   Bit b3 - NODC - Set to 0 in order to select 'CLKi is CMOS output' 
	   Remaining bits are not applicable in synchronous serial mode. Set to 0.	*/	
	u0smr3 = 0x00;

	/* Unused in synchronous serial mode. Set to 0.	*/
	u0smr4 = 0x00;
	
	/* Disable interrupts	*/
	DISABLE_IRQ

	/* Interrupt Control Register for UART0 transmit
	b2:b0 	- ILVL2:ILVL0 	- 011 (Interrupt priority 3 selected for UART0
								   transmit)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0.)  
	b5 		- Reserved		- 0
	b7:b6 	- Reserved		- 0 		*/
		
	s0tic = 0x03;
	
	/* Enable interrupts	*/
	ENABLE_IRQ	
}
/******************************************************************************
End of function uart0_init
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: uart4_init
* Description 	: Configures UART4 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void uart4_init(void) 
{
	/* Port pin configuration */
	/* Disable Interrupts	*/
	DISABLE_IRQ
	
	/* Enable writing to port 9 configuration registers */	   
	prc2 = 1;

	/* Configure the port pins as follows -
	  b0 - Reserved 	- 0
   	  b1 - pd9_1 		- 0 (p9_1 pin as Input)
	  b2 - Reserved 	- 0		
	  b3 - pd9_3 		- 1 (p9_3 pin as Input)
   	  b4 - STPS	 		- 1 (p9_4 pin as Output)
   	  b5 - PRY		 	- 0 (p9_5 pin as Input)
   	  b6 - PRYE		 	- 1 (p9_6 pin as Output)
  	  b7 - IOPOL		- 0 (p9_7 pin as Input)		*/
	
	pd9 = 0x58;
	
	/* Disable writing to port 9 configuration registers */	   
	prc2 = 0;

	/* Enable writing to port 9 configuration registers */	   
	prc2 = 1;

	/* Configure the pin p9_6 as TXD4	*/
	p9_6s = 0x03;
	
	/* Disable writing to port 9 configuration registers */	   
	prc2 = 0;

	/* Enable Interrupts	*/
	ENABLE_IRQ

	/* Set UART4 clock bit rate */
	u4brg = (unsigned char)(((f1_CLK_SPEED/2)/(BIT_RATE))-1);

	/* UART4 transmit/receive mode register 
	  b2:b0	- SMD12:SMD1 - 001 (Synchronous Serial Mode selected)
   	  b3	- CKDIR		 - 1 (External clock selected)
   	  b4	- STPS		 - 0 (1 Stop bit)
   	  b5	- PRY		 - 0 (No parity used)
   	  b6	- PRYE		 - 0 (No parity used)
  	  b7	- IOPOL		 - 0 (TXD, RXD polarity not inverted) 	*/
	  
	 u4mr = 0x09;

	/* UART4 transmit/receive control register 0 
	  b1:b0	- CLK01:CLK0 - 0 (f1 clock source selected)
   	  b2 	- CRS 		 - 0 (CTS/RTS function select bit (Set to 0))
  	  b3	- TXEPT		 - 0 (Clear transmit register empty flag)
   	  b4	- CRD		 - 1 (Disable CTS/RTS function)
   	  b5	- NCH		 - 0 (CMOS Data output selected)
   	  b6	- CKPOL		 - 1 (Transmit data is output at the rising edge of
	  						  transmit/receive clock and receive data is input
							  at the falling edge.
  	  b7	- UFORM		 - 1 (MSB first selected) */
	  
  	u4c0 = 0xd0; 		

	/* UART4 transmit/receive control register 1 
	b0 		- TE		- 1 (Enable transmission)	
	b1	 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
	b2 		- RE 		- 1 (Enable reception)
	b3 		- RI		- 0 (Clear the 'Receive complete' flag)
	b4		- U4lRS	 	- 0	(UART4 transmit interrupt source - U4TB
							 register empty)
	b5 		- U0RRM  	- 1 (Continuous receive mode enabled) 
	b6		- UOLCH		- 0 (non-inverse data logic selected)
	b7		- UOERE		- 0 (Error signal output disable) */
	
  	u4c1 = 0x25; 	

	/* Unused in synchronous serial mode. Set to 0.	*/
	u4smr = 0x00;

	/* Unused in synchronous serial mode. Set to 0.	*/	
	u4smr2 = 0x00;

	/* UART4 Special Mode Register 3
	   Bit b3 - NODC - Set to 0 in order to select 'CLKi is CMOS output' 
	   Remaining bits are not applicable in synchronous serial mode. Set to 0.	*/	
	u4smr3 = 0x00;

	/* Unused in synchronous serial mode. Set to 0.	*/
	u4smr4 = 0x00;
	
	/* Disable interrupts	*/
	DISABLE_IRQ

	/* Interrupt Control Register for UART4 receive
	b2:b0 	- ILVL2:ILVL0 	- 101 (Interrupt priority 5 selected for UART4
								   transmit)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0.)  
	b5 		- Reserved		- 0
	b7:b6 	- Reserved		- 0 		*/
	
	s4ric = 0x05;
	
	/* Enable interrupts	*/
	ENABLE_IRQ	
	
	/* Dummy write to UART4 receive & transmit register	*/
	u4rb = 0x00U;
	u4tb = 0x00U;
}
/******************************************************************************
End of function uart4_init
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _uart0_trans
* Description 	: Interrupt handler for UART0 transmit
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_uart0_trans(vect=17)
void _uart0_trans(void)
{
	/* Clear the 'transmission complete' flag.	*/
	ir_s0tic = 0;
}
/******************************************************************************
End of ISR _uart0_trans
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _uart4_receive
* Description 	: Interrupt handler for UART4 receive
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_uart4_receive(vect=38)
void _uart4_receive(void)
{
	/* Used to reference a specific location in the array while string the
	   received data.	*/	
	static unsigned char uc_cnt;
	
	/* Copy the received data to the global variable 'c_RecBuff'	*/
	c_RecBuff[uc_cnt] = (char)u4rb ;
	
	/* Dummy write to the receive register to reinitiate a receive operation.	*/
	u4rb = 0x00;
	
	/* Check if the buffer size is exceed. If it is then reset the 'uc_cnt'
	   variable.	*/
	if(uc_cnt++ >= sizeof(c_RecBuff))
	{
		/* Reinitialize the buffer reference.	*/
		uc_cnt = 0;	
	}

	/* Clear the 'transmission complete' flag.	*/	
	ir_s4ric = 0;
}
/******************************************************************************
End of ISR _uart4_receive
******************************************************************************/

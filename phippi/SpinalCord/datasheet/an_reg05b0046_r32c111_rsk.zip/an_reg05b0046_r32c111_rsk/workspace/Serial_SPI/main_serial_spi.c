/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_serial_spi.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Demonstration of R32C111 on-chip Serial Interface 
*
* Operation: 	1. Make the following connections on RSKR32C111 -
*					a. 	CPU port pin - p7_6 (J1-31) (p76)-> P7_3 (J1-34) (SS2n)
*			  		b. 	CPU port pin - p6_1 (J2-10) (CLK0)-> p7_2 (J1-35) (CLK2)
*					c.  CPU port pin - p6_2 (J2-9)  (RXD0)-> p7_1 (J1-36) (STXD2)
					d.  CPU port pin - p6_3 (J2-8)  (TXD0)=> p7_0 (J2-1) (SRXD2)
*			    2. Build this application and download it to the target.
*			    3. Click on the "Reset Go" icon available on 'Debug' toolbar.
*				4. The debug LCD will display the message "SPI-COMM".
*				5. A string "Renesas" will be transmitted from UART0
*				   to serial port UART2.
*				6. The string received by UART2 will be displayed on the
*				   debug LCD.
*				7. The user can also examine the string received by UART2 in
*				   the variable "c_RecBuff" using HEW C watch window.
* Note: This file contains a compiler directive "#pragma interrupt 
* functionname" which instructs the compiler to treat the following 
* function as an interrupt. The compiler will save all registers
* used in the function and replace the normal RTS instruction with an REIT
* instruction at the end of the function.		
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides useful macros and function prototypes for
	controlling the LCD interface.	*/
#include "lcd.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main_serial_spi.h"

/*******************************************************************************
Constants
*******************************************************************************/
/* Constant data to be transmitted	*/
const char c_data[8] = "Renesas";

/*******************************************************************************
Global Variables
*******************************************************************************/
/* Buffer to store the received data	*/
volatile char c_RecBuff[8];

/*******************************************************************************
User Program Code
*******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routines for SPI master and
*				  slave 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void main(void)				
{
	/* Used as a loop counter	*/
	unsigned char ucLoopcnt;
	
	/* Reset the LCD module */
	InitialiseDisplay();

	/* Display Renesas Splash Screen */
	DisplayString(LCD_LINE1,APP_NAME);
		
	/* Configure UART0 for transmission	*/
	SPI_Master_init();
	
	/* Configure UART2 for reception	*/
	SPI_Slave_init();
	
	/* Enable interrupts	*/
	ENABLE_IRQ

	/* This loop transmits all characters contained in the 'c_data' buffer 	*/
	for (ucLoopcnt=0; ucLoopcnt<sizeof(c_data); ucLoopcnt++)
	{
		while(ti_u0c1 == 0)
		{
			/* Wait for previous transmission to complete */
		}	 		 

 		/* Load the data to be transmitted, in the transmit buffer */
		u0tb = (short) c_data[ucLoopcnt];
	}
	
	/*	Display the received string on the second line of the debug LCD. */
	DisplayString(LCD_LINE2, c_RecBuff);

	/*	This loop should never exit.  */
	while (1);
}         
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: SPI_Master_init
* Description 	: Configures UART0 in transmit mode
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void SPI_Master_init(void) 
{
	/* Configure pin p6_0 as follows - Output port pin  	*/	
	pd6_0= 1; 	
	p6_0s = 0; 
	p6_0=1; 
	
	/* Configure pin p7_2 as follows - CLK0, Input pin  	*/
	pd6_1 = 1;	
	p6_1s = 0x3;
	
	/* Configure pin p6_2 as follows - RXD0, Input pin  	*/
	pd6_2 = 0; 

	/* Configure pin p6_3 as follows - TXD0, Output pin  	*/
	pd6_3 =  1;
	p6_3s = 0x3;

	/* Configure pin p7_6 as follows - Output port pin (to select slave device)	*/	
	p7_6 = 0;
	pd7_6 = 1;
	p7_6s = 0;
		
	/* Set master clock bit rate. Please refer to the macro BIT_RATE in the 
	   header file for actual bit rate  */
	u0brg = (unsigned char)(((f1_CLK_SPEED)/(2*BIT_RATE))-1); 

	/* UART0 transmit/receive mode register 
	  b2:b0	- SMD2:SMD0  - 001 (serial synchronous interface mode selected)
   	  b3	- CKDIR		 - 0 (Internal clock selected)
   	  b4	- STPS		 - 0 (1 Stop bit)
   	  b5	- PRY		 - 0 (No parity used)
   	  b6	- PRYE		 - 0 (No parity used)
  	  b7	- IOPOL		 - 0 (TXD, RXD polarity not inverted) 	*/
		
	u0mr = 0x01;
	   
	/* UART0 transmit/receive control register 0 
	  b1:b0	- CLK01:CLK0 - 00 (U0BRG count source select bits -f1 selected)
   	  b2 	- CRS 		 - 0 (CTS/RTS function select bit (Set to 0))
  	  b3	- TXEPT		 - 0 (Clear transmit register empty flag)
   	  b4	- CRD		 - 1 (Disable CTS/RTS function)
   	  b5	- NCH		 - 0 (N-channel open drain output selected)
   	  b6	- CKPOL		 - 1 (Transmit data is output at the rising edge of
	  						  transmit/receive clock and receive data is input at
							  the falling edge.
  	  b7	- UFORM		 - 1 (MSB first selected) */
		
  	u0c0 = 0xd0; 		

	/* UART0 transmit/receive control register 1 
   	  b0 	- TE		- 1 (Enable transmission)	
	  b1 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
	  b2 	- RE 		- 1 (Enable reception)
	  b3 	- RI		- 0 (Clear the 'Receive complete' flag)
	  b4 	- UiIRS     - 0 
	  b5	- UiRRM		- 1 (Use continuous receive )
	  b7:b6	- Reserved	- 00 (Set to 00) */
		
  	u0c1 = 0x25; 	

	/* Unused in synchronous serial mode. Set to 0.	*/
	u0smr = 0x00;

	/* Unused in synchronous serial mode. Set to 0.	*/	
	u0smr2 = 0x00;

	/* UART0 Special Mode Register 3
	   b0		SSE			-1 (SS0n pin enabled)	  
	   b1		CKPH 		-0 (No delayed clock)
	   b2		DINC		-0 (set to 0 in master mode)
	   b3		NODC 		-0 (CLKi pin in N-channel open drain output)
	   b4 		ERR			-0 (set to 0 )
	   b7:b5 	DL2:DL0 	-000 (Select as 0 in serial synchronous mode)	*/
	   
	u0smr3 = 0x01;

	/* Unused in synchronous serial mode. Set to 0.	*/
	u0smr4 = 0x00;
	
	/* Disable interrupts	*/
	DISABLE_IRQ
	
	/* Interrupt Control Register for UART0 transmit
	b2:b0 	- ILVL2:ILVL0 	- 011 (Interrupt priority 3 selected for UART0
								   transmit)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0.)  
	b5 		- Reserved		- 0
	b7:b6 	- Reserved		- 0 		*/
		
	s0tic = 0x03;

	/* Enable interrupts	*/
	ENABLE_IRQ
}
/******************************************************************************
End of function SPI_Master_init
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: SPI_Slave_init
* Description 	: Configures UART2 in receive mode
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void SPI_Slave_init(void) 
{
	/* Configure pin p7_0 as follows - SRXD2, Input pin  	*/
	pd7_0 = 0; 

	/* Configure pin p7_1 as follows - STXD2, Output pin  	*/
	pd7_1 = 1 ; 
	p7_1s = 0x4; 

	/* Configure pin p7_2 as follows - CLK2, Input pin  	*/
	p7_2s = 0x3;
	pd7_2 = 0;
	
	/* Configure pin p7_3 as follows - SS2n, Input pin  	*/	
	pd7_3 = 0; 	
	
	/* Set slave clock bit rate. Please refer to the macro BIT_RATE in the 
	   header file for actual bit rate  */
	u2brg = (unsigned char)(((f1_CLK_SPEED)/(2*BIT_RATE))-1); 

	/* UART2 transmit/receive mode register 
	  b2:b0	- SMD2:SMD0  - 001 (Synchronous Serial Mode selected)
   	  b3	- CKDIR		 - 1 (External clock selected)
   	  b4	- STPS		 - 0 (1 Stop bit)
   	  b5	- PRY		 - 0 (No parity used)
   	  b6	- PRYE		 - 0 (No parity used)
  	  b7	- IOPOL		 - 0 (TXD, RXD polarity not inverted) 	*/
	  
	 u2mr = 0x09;

	/* UART2 transmit/receive control register 0 
	  b1:b0	- CLK1:CLK0  - 0 (U2BRG count source select bits -f1SIO or f2SIO
	  						  selected)
   	  b2 	- CRS 		 - 0 (CTS/RTS function select bit (Set to 0))
  	  b3	- TXEPT		 - 0 (Clear transmit register empty flag)
   	  b4	- CRD		 - 1 (Disable CTS/RTS function)
   	  b5	- NCH		 - 1 (CMOS Data output selected)
   	  b6	- CKPOL		 - 1 (Transmit data is output at the rising edge of
	  						  transmit/receive clock and receive data is input
							  at the falling edge.
  	  b7	- UFORM		 - 1 (MSB first selected) */
	  
  	u2c0 = 0xF0; 		

	/* UART2 transmit/receive control register 1 
	  b0 		- TE		- 1 (Enable transmission)	
	  b1	 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
	  b2 		- RE 		- 1 (Enable reception)
	  b3 		- RI		- 0 (Clear the 'Receive complete' flag)
	  b4 		- UiIRS     - 0 
	  b5		- UiRRM		- 1 (Use continuous receive )
	  b7:b6		- Reserved	- 00 (Set to 00) */
	
  	u2c1 = 0x25; 	

	/* Unused in synchronous serial mode. Set to 0.	*/
	u2smr = 0x00;

	/* Unused in synchronous serial mode. Set to 0.	*/	
	u2smr2 = 0x00;

	/* UART2 Special Mode Register 3
	   b0		SSE			- 1	(SS* pin enabled)
	   b1		CKPH 		- 0	(No delayed clock)
	   b2		DINC		- 1	(set to 1 in slave mode)
	   b3		NODC 		- 0	(CLKi pin in N-channel open drain output)
	   b4 		ERR			- 0	(set to 0 )
	   b7:b5 	DL2:DL0 	- 000 (Select as 0 in serial synchronous mode)	*/
	   
	u2smr3 = 0x05;

	/* Unused in synchronous serial mode. Set to 0.	*/
	u2smr4 = 0x00;

	/* Disable Interrupts	*/
	DISABLE_IRQ
	
	/* Interrupt Control Register for UART2 receive
	b2:b0 	- ILVL2:ILVL0 	- 101 (Interrupt priority 5 selected for UART2
								   transmit)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0.)  
	b5 		- Reserved		- 0
	b7:b6 	- Reserved		- 0 		*/
	
	s2ric = 0x05;
	
	/* Enable Interrupts	*/
	ENABLE_IRQ
	
	/* Dummy write to UART2 transmit register	*/
	u2tb = 0x00;
}
/******************************************************************************
End of function SPI_Slave_init
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _uart0_trans
* Description 	: Interrupt handler for UART0 transmit
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_uart0_trans(vect=17)
void _uart0_trans(void)
{
	/* Clear the 'transmission complete' flag.	*/
	ir_s0tic = 0;
}
/******************************************************************************
End of ISR _uart0_trans
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _uart2_receive
* Description 	: Interrupt handler for UART2 receive
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_uart2_receive(vect=34)
void _uart2_receive(void)
{
	/* Used to reference a specific location in the array while string the
	   received data.	*/	
	static unsigned char uc_cnt=0;
	
	/* Copy the received data to the global variable 'c_RecBuff'	*/
	c_RecBuff[uc_cnt] = (char) u2rb ;
	
	/* Dummy write to the receive register to reinitiate a receive operation.	*/
	u2rb = 0x00;

	/* Check if the buffer size is exceed. If it is then reset the 'uc_cnt'
	   variable.	*/
	if(uc_cnt++ >= sizeof(c_RecBuff))
	{
		/* Reinitialize the buffer reference.	*/
		uc_cnt = 0;	
	}

	/* Clear the 'transmission complete' flag.	*/	
	ir_s2ric = 0;
}
/******************************************************************************
End of ISR _uart2_receive
******************************************************************************/

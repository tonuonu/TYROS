/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: timeradc.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description   : Configures Timer A0 & ADC channel AN0 to control flashing 
*				  time of user LEDs.
******************************************************************************/

/******************************************************************************
* History 		: 30.10.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides prototype for timer & ADC controlling
	functions.	*/
#include "timerADC.h"

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: TimerADC
* Description 	: The ADC value is used to change the period of the timer, 
				  which controls the flashing of the user LEDs
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void TimerADC(void)
{
	/* Configures the Timer A0	*/
	StartTimer();
	
	/* Configures ADC channel 0 in oneshot mode	*/
	StartADC();
}     
/**********************************************************************************
End of function TimerADC
***********************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: StartADC
* Description 	: Configures the ADC channel AN0 as follows -
*				  One Shot, software triggered
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void StartADC(void)
{
	/* Stop the ADC */
	adst_ad0con0 = 1;
	
	/* ADC Control Register 0 
	b2:b1:b0	- CH2:CH1:CH0	- 000 (Analog Input Pin Select Bit. AN0 selected)
	b4:b3		- MD1:MD0		- 00  (ADC One-shot mode)
	b5			- TRG			- 0   (Software trigger)
	b6			- ADST			- 0   (AD conversion stopped)
	b7			- CKS0			- 1	  (Frequency select bit. fAD�1 selected) */

	ad0con0 = 0x80; 

	/* ADC Control Register 1
	b1:b0	- SCAN1:SCAN0	- 00 (AN0 selected)
	b2		- MD2			- 0  (single sweep mode)
	b3		- BITS			- 1  (10 bit mode)
	b4		- CKS1			- 1  (Frequency select bit. fAD�1 selected)
	b5		- VCUT 			- 1  (VREF connected)
	b7:b6	- OPA1:OPA0		- 00 (Not applicable) */				
	
	ad0con1 = 0x38;	
	
	/* ADC Control Register 2 
	b0		- SMP			- 1  (With sample & hold function)
	b2:b1	- APS1:APS0		- 00 (AN0 selected)
	b4:b3	- Reserved		- 00
	b5		- TRG0			- 0  (Not applicable in software trigger mode)
	b7:b6	- Reserved		- 00 */
	
	ad0con2 = 0x01;
	
	/* ADC Control Register 3
	b0			- DUS			- 0 (DMAC operating mode disabled)
	b1 			- MSS			- 0 (Multi-port sweep mode disabled)
	b2			- CKS2			- 0 (Frequency select bit. fAD�1 selected)
	b4:b3		- MSF1:MSF0		- 00 (AN0 Selected)
	b5:b6:b7	- Reserved		- 000 */
	
	ad0con3 = 0x00;
	
	/* ADC Control Register 4
	b1:b0		- Reserved		- 00
	b3:b2		- MPS11:MPS10	- 00 (Not used)
	b7:b6:b5:b4 - Reserved		- 0000 */
	
	ad0con4 = 0x00;

	/* If the first conversion value is important then delay the start for 1�s
	   while VREF settles */
	
	/* Start the ADC */
	adst_ad0con0 = 1;
}
/**********************************************************************************
End of function StartADC
***********************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: StartTimer
* Description 	: Configures the timer A0 as follows -
*					clock - f/8, count down
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void StartTimer(void)
{
	/* Timer 0 mode register,  
	b1:b0 		- TMOD1:TMOD0 - 00 (timer mode)
	b2	 		- Reserved 	  - 0  
	b4:b3 		- MR2:MR1 	  - 00 (TA0IN pin functions as programmable I/O port) 
	b5			- Reserved	  - 0		
	b7:b6 		- TCK1:TCK0   - 01 (f8 as frequency source) */
	ta0mr = 0x40;
			
	/* Timer A0 starts counting down from 0x0FFF */
	ta0 = 0x0FFFu;
	   
	/* start timer A0 (defaults to down)*/
	ta0s = 1; 		
}
/**********************************************************************************
End of function StartTimer
***********************************************************************************/

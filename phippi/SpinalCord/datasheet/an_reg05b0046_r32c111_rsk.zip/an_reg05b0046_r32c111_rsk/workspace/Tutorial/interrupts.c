/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: interrupts.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Contains the function to Configure the interrupt controller
*				  and interrupts handlers for interrupts used in this
*                 application
*
* Note			: This file includes following  compiler directive - 
*				  #pragma interrupt functionname
* 				  This directive instructs the compiler to treat the following
*                 function as an interrupt. The compiler will save all registers
*				  used in the function and replace the normal RTS instruction 
*				  with an REIT instruction at the end of the function.
* 				  The intprg.c file must be modified to point the appropriate
*				  vector at this function.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/* Following header file provides prototypes for interrupt configuring
   functions */
#include "interrupts.h"
/* Following header file provides function prototypes for LED controlling
   functions */
#include "flashleds.h"

/******************************************************************************
Global variables
******************************************************************************/
extern volatile char gcKeyPressed;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: ConfigureInterrupts
* Description 	: Configures the required interrupts.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void ConfigureInterrupts(void)
{	
	/* SW1 connected to INT0n and configured as follows 
	Interrupt Control Register for INT0 
	b2:b0 	- ILVL2:ILVL0 	- 011 (Interrupt priority 3 selected for INT0)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Falling edge selected.)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	int0ic = 0x03;

	/* SW2 connected to INT1n and configured as follows 
	Interrupt Control Register for INT1
	b2:b0 	- ILVL2:ILVL0 	- 011 (Interrupt priority 3 selected for INT1)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Falling edge selected.)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	int1ic = 0x03;

	/* SW3 connected to INT2n and configured as follows 
	Interrupt Control Register for INT2
	b2:b0 	- ILVL2:ILVL0 	- 011 (Interrupt priority 3 selected for INT2)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Falling edge selected.)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	int2ic = 0x03;

	/* Interrupt Control Register for Timer A0
	b2:b0 	- ILVL2:ILVL0 	- 100 (Interrupt priority 4 selected for Timer A0)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	ta0ic = 0x04;
	
	/* Enable interrupts by setting i flag */
	ENABLE_IRQ	
}
/******************************************************************************
End of function ConfigureInterrupts
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _timer_a0
* Description 	: Decrements a counter. If the counter is zero, toggle the LEDs 
*				  and reload the counter
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_timer_a0(vect=12)
void _timer_a0(void)
{
	static unsigned char ucCounter = LED_INTERVAL;
	short usTempStore;
	
	/* Check if ADC conversion is complete */
	if (adst_ad0con0 == 0)
	{
		/* Store the ADC value */
		usTempStore = ad00 * 10;
		
		/* Use the ADC reading as timer upper limit */
		if(usTempStore < 1000) 
		{
			usTempStore = 1000;
		}
		
		/* Use the ADC value to configure the timer */
		ta0 = usTempStore; 
				
		/* Re-start the ADC */
		adst_ad0con0 = 1;
	}

	/* Toggle the LEDs */
	if (--ucCounter == 0x00)
	{   
		ucCounter = LED_INTERVAL;
		ToggleLEDs();
	}
	
	/* Clear interrupt flag */
	/* Interrupt flags are cleared automatically */
}
/**********************************************************************************
End of ISR _timer_a0
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _int0
* Description 	: Interrupt Handler for INT0. SW1 is connected to INT0
*				  interrupt pin
* Argument  	: none
* Return value  : If SW1 is pressed global 'gcKeyPressed' is set to '1'.
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_int0(vect=31)
void _int0(void)
{
	unsigned char ucDelay = 0x3F;
	
	while (ucDelay--)
	{
		/* Debounce delay */
	}
	
	/* Set a flag to say the switch has been pressed */
	gcKeyPressed = '1';

	/* Clear interrupt flag */
	/* Interrupt flags are cleared automatically */
}
/**********************************************************************************
End of ISR _int0
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _int1
* Description 	: Interrupt Handler for INT1. SW2 is connected to INT1
*				  interrupt pin
* Argument  	: none
* Return value  : If SW2 is pressed global 'gcKeyPressed' is set to '2'.
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_int1(vect=30)
void _int1(void)
{
	unsigned char ucDelay = 0x3F;

	while (ucDelay--)
	{
		/* Debounce delay */
	}
	
	/* Set a flag to say the switch has been pressed */
	gcKeyPressed = '2';

	/* Clear interrupt flag */
	/* Interrupt flags are cleared automatically */
}
/**********************************************************************************
End of ISR _int1
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _int2
* Description 	: Interrupt Handler for INT2. SW3 is connected to INT2
*				  interrupt pin
* Argument  	: none
* Return value  : If SW3 is pressed global 'gcKeyPressed' is set to '3'.
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_int2(vect=29)
void _int2(void)
{
	unsigned char ucDelay = 0x3F;

	while (ucDelay--)
	{
		/* Switch debouncing delay	*/
	}

	/* Set a flag to say the switch has been pressed */
	gcKeyPressed = '3';

	/* Clear interrupt flag */
	/* Interrupt flags are cleared automatically */
}
/**********************************************************************************
End of ISR _int2
***********************************************************************************/

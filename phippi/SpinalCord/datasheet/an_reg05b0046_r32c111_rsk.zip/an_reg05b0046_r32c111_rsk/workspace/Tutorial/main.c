/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: This is the main tutorial code. This code will call three
*                 functions to demonstrate Port pin control (FlashLEDs),
*				  Interrupt usage (TimerADC) and C variable initialization
*				  (Statics_Test). Code is also included to drive the optional
*				  LCD module.
* Operation:
*  				1. Build this application and download it to target.
*				2. Press 'Reset Go'. All the LEDs will start flashing.
*  				3. Pressing any of the switches will allow the user to control
*  		   		    the flashing speed using potentiometer.
*
*				  Please refer to the tutorial manual for more information on
*				  the program flow.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main.h"
/*	Following header file provides prototypes for LED controlling functions. */
#include "flashleds.h"
/*	Following header file provides useful macros and function prototypes for
	controlling the LCD interface.	*/
#include "lcd.h"
/*	Following header file provides prototype for timer & ADC controlling
	functions.	*/
#include "timeradc.h"

/******************************************************************************
Global variables
******************************************************************************/
/* Global initialised variable*/
char ucStr[9]=" STATIC ";
/* Constant Data for replacement */
const char ucReplace[] = "TESTTEST";
/* Global variable changed by pressing switches */
unsigned volatile char gcKeyPressed = 0x00;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description 	: Main program. This function calls timer, ADC & LCD 
				  initialisation functions. The user LEDs flashes until 
				  the user presses a switch on the RSK.  
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void main(void)				
{
	/* 	Reset the LCD module. */
	InitialiseDisplay();

	/* 	Display Renesas Splash Screen. */
	DisplayString(LCD_LINE1, "Renesas");
	DisplayString(LCD_LINE2, NICKNAME);

	/* 	Flash the user LEDs for some time or until a push button is pressed. */
	FlashLEDs();

	/* 	Flash the user LEDs at a rate set by the user potentiometer (ADC) using
		interrupts. */
	TimerADC();

	/*	Demonstration of initialised variables. Use this function with the
		debugger.	*/
	Statics_Test();
	
	/* This function must not exit */
	while(1);
}         
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: Statics_Test
* Description 	: Displays an initialised string, then modifies it, a character
*				  at a time, displaying it at each stage.
*				  Finally NICKNAME is displayed. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void Statics_Test(void)
{
	unsigned char ucCount;
	
	DisplayString(LCD_LINE2,ucStr);	

	/*  At this point please right click on the 'ucStr' variable and select
    'Instant Watch'. A dialog will be displayed showing the current value
	 of the variable. Select 'Add' in the dialog and a new 'Watch Window'
	 will open. Step through the following code to see that the initialised
	 data is being overwritten with the different data. */
	for (ucCount=0; ucCount<8; ucCount++)
	{  
		/* Put a breakpoint here and press F5 to step through the string 
	     overwrite sequence */
		ucStr[ucCount] = ucReplace[ucCount];
		
		/* Delay */
		DisplayDelay(0xFFFFu);	
		
		/* Display the updated string on the LCD */
		DisplayString(LCD_LINE2, ucStr);
		
		/* Delay */
		DisplayDelay(0xFFFFu);	
	}	
	/* Fill a NULL character */
	ucStr[ucCount] = '\0';

	/*	RSK name is displayed on the LCD.	*/
	DisplayString(LCD_LINE2, NICKNAME);	
}
/******************************************************************************
End of function Statics_Test
******************************************************************************/
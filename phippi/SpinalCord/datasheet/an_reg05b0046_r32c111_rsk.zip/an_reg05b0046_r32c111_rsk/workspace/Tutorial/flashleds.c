/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: flashleds.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Function to Flash the user LEDs for 200 times or until one of 
* 				  the user switches is pressed.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/* Following header file provides function prototypes for LED controlling
   functions */
#include "flashleds.h"

/******************************************************************************
Global variables
******************************************************************************/
extern volatile char gcKeyPressed;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: FlashLEDs
* Description 	: Flashes the user LEDs on the RSK
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void FlashLEDs(void)
{   
    unsigned long ulLed_Delay;
    unsigned char ucLEDcount;
	
    /* Flash the LEDs for 200 times or until a user switch is pressed */
	for(ucLEDcount=0; ucLEDcount<200; ucLEDcount++)
	{   
		/* Check if key press is detected	*/
		if( gcKeyPressed > 0x00) 
		{
			break;
		}
 		
		for(ulLed_Delay=0; ulLed_Delay<400000; ulLed_Delay++)
		{
			/* LED Flashing Delay */
		}
	 	
		/*	Toggles the LEDs after a specific delay. */
	    ToggleLEDs();
	}
}                                            
/******************************************************************************
End of function FlashLEDs
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: ToggleLEDs
* Description 	: Toggles the LEDs on the RSK
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void ToggleLEDs(void)
{
	/*	Toggle the state of the user LEDs	*/
    LED_PORT_DR ^= LED_BIT;     		
}
/******************************************************************************
End of function ToggleLEDs
******************************************************************************/

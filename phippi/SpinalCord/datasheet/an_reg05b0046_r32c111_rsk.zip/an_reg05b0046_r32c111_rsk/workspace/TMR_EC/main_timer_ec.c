/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_timer_ec.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Timer tb0 is configured in event counter mode. An interrupt is
*				 generated after it counts the 100 events.  LED2 will blink each 
*				 time the interrupt service routine is executed.    
*			 	 The event that TB0 is counting is tb2 underflows which occur
*				 every 5 mSec (approx).
*
* Operation     : 1. Build this application and download it to the target. 
*				  2. Click on the "Reset Go" icon available on 'Debug Run' toolbar.  
*				  3. LED2 will start blinking.
*  				  4. A waveform can be observed at LED2 (J3-3). The LED2 flashes
*					 after around every 500 ms (approx). 
*					 observe the variable usEvent_count in HEW watch window.
*				  5. Same result can also be observed on the debug LCD.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"	
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include 	"main_timer_ec.h"
/*	Following header file provides useful macros and function prototypes for
	controlling the LCD interface.	*/
#include	"lcd.h"

/******************************************************************************
Global variables
******************************************************************************/
unsigned short usEvent_count;

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routine for timer.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void main (void)
{
	/* The hex result value is converted into string and stored in this array. */
	char str_Count[8];
		
	/* 	Reset the LCD module. */
	InitialiseDisplay();
	
	/* Turn OFF LED2 */
	LED2 = LED_OFF;

	/* Initialisation of timer B0 and B2 */
	timerb0_init();
	timerb2_init();
	
	/* Disable interrupts */
    DISABLE_IRQ			
	
   	/* Set the interrupt priority of tb0 */
	tb0ic = 0x03;	
    
	/* Enable interrupts */	
	ENABLE_IRQ	
	
	/* Start timers B0 & B2*/
   	tb0s = 1;
	tb2s = 1;
	
  	while (1)
	{
		/* Convert the hex value in string */
		Convert_Number_ToString(usEvent_count, str_Count);
		
		/* Display "Evecount" on debug LCD Line 1 */
		DisplayString(LCD_LINE1,"EveCount"); 
		
		/* Display event count value on debug LCD Line 2 */
		DisplayString(LCD_LINE2, str_Count); 
	}
}
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: timerb0_init
* Description 	: Initializes Timer TB0 in event counter mode. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void timerb0_init(void)
{
	/* Set underflow count, desired count -1 */
	tb0 = 99;
	
	/* TB0 mode register 
    b1:b0	TMOD1:TMOD0		-01 Operating mode select bit (EVENT COUNTER MODE)
    b2		Reserved 		-0  SHould be written with 0
    b3		MR1			    -0  Count polarity select     COUNT FALLING EDGES
    b4		MR2			    -0  UDF fregister setting enabled 
    b5		MR3			    -0  Should be set to 0 IN EVENT COUNTER MODE     
    b6		TCK0		    -0  Reload Type
    b7		TCK1		    -1  The overflow of Timer B2 enabled */
	
	tb0mr = 0x81;
}
/******************************************************************************
End of function timerb0_init
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: timerb2_init
* Description 	: Initializes Timer TB2 in timer mode. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void timerb2_init(void)
{
	/* Timer mode, f2n divided by 30 output ((25MHz/30)*.005 -1) */
    tb2 = 4165u;  
	
	/* TImer B2 mode register
	
	b1:b0 	- TMOD0:TMOD1 - 00 (Operation mode select bit. Set to 00 for timer mode)
	b2 		- MR0 		  - 0  (Set to 0 for no pulse output)
	b4:b3 	- MR2:MR1 	  - 00 (Set to 00 for gate function not available)
	b5 		- MR3 		  - 0  (Set to 0 in timer mode)
	b7:b6 	- TCK1:TCK0   - 10 (Count source select bit. Set to 10 to select f2n
			  					frequency source) */		
	tb2mr = 0x80;

	/* Set the prescaler so n = 15. (i.e 30 (2*15) 25MHz/30 = 0.937uS) */
	tcspr = 0x0f; 
	  
	/* Enable prescaler*/
	cst_tcspr =1;		
}
/******************************************************************************
End of function timerb2_init
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _timer_b0
* Description 	: Timer B0 Interrupt Service Routine. The ISR flashes the LED2
*				  and increments 'usEvent_count' 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_timer_b0(vect=21)
void _timer_b0(void)
{
	unsigned short delaycntr=0;
	
	/* Increment the event count variable  */
 	usEvent_count++;		     		
	
 	/* Turn ON LED2	 */
	LED2 = LED_ON;
		  
 	/* Software delay for LED so that the user can see LED flashing */
	while(delaycntr <0xffffu)  	
	{
		delaycntr++;    
	}	
	
	/* Turn OFF LED2  */	
 	LED2 = LED_OFF; 
}
/**********************************************************************************
End of ISR timer b0 handler
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline		: Convert_Number_ToString
* Description	: Converts an unsigned short value into string of hexadecimals.
* Argument		: (unsigned short) num - value to be converted;
*				  (char *) buffer - pointer to output buffer (8 bytes length).		
* Return value	: none
*��FUNC COMMENT END��*********************************************************/

void Convert_Number_ToString(unsigned short num, char* buffer)
{
	char a;

	/* "=H'" characters before string of hexadecimals */
	buffer[0] = '=';
	buffer[1] = 'H';
	buffer[2] = '\'';
	
	/* Forming the string of hexadecimals */
	a = (char)((num & 0x0F00)>> 8);
	buffer[3] = (a < 0x0A) ? (a+0x30):(a+0x37); 
	a = (char)((num & 0x00F0)>> 4);
	buffer[4] = (a < 0x0A) ? (a+0x30):(a+0x37); 
	a = (char)(num & 0x000F);
	buffer[5] = (a < 0x0A) ? (a+0x30):(a+0x37); 

	/* Add two spaces for string termination */
	buffer[6] = ' ';
	buffer[7] = ' ';
}
/******************************************************************************
End of function Convert_Number_ToString
******************************************************************************/

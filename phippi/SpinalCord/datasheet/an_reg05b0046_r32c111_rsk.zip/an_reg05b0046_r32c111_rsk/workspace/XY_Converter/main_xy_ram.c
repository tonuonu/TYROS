/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_xy_ram.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: This sample application demonstrates the X-Y ram conversion 
*				  operation. The X-Y conversion rotates 16 � 16-bit matrix data 
*				  by 90 degrees. The input 16 � 16-bit matrix data and rotated 
*				  16 � 16-bit matrix data can be observed in HEW watch window 
*				  as well as PC COM port terminal application (HyperTerminal).    
*
* Operation 	: 1. Make a connection between the 'SERIAL' connector of 
*				     RSKR32C111 and PC COM port using standard RS232 cable.
*				  2. Run a terminal application (such as HyperTerminal) on the PC.
*				  3. Configure the terminal application as follows -
*					 BAUD:19200, 8 data bits, 1 stop bit, no parity.
*				  4. Build this application and download it to the target. 
*				  5. Click on the "Reset Go" icon available on 'Debug Run' toolbar.	 
*				  6. Add the variables 'xy_Inputbuff' and 'xy_Outputbuff' in HEW
*                    C watch window.	 	
*				  7. The result of X-Y ram conversion operation is stored in 
*					 16 � 16-bit matrix variable 'xy_Outputbuff' which contains  
*					 'xy_Inputbuff' data rotated by 90 degrees. 
*				  8. The bit positions of 16 � 16-bit matrix variables 
*					 'xy_Inputbuff' and 'xy_Outputbuff' can be observed on 
*					  PC COM port terminal application (HyperTerminal) by pressing SW3. 
*
* Note			: This file includes following  compiler directive - 
*				  #pragma interrupt functionname
* 				  This directive instructs the compiler to treat the following
*                 function as an interrupt. The compiler will save all registers
*				  used in the function and replace the normal RTS instruction 
*				  with an REIT instruction at the end of the function.
* 				  The intprg.c file must be modified to point the appropriate
*				  vector at this function.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main_xy_ram.h"
/* Following header file provides common defines for widely used items. */
#include	"rskr32c111def.h"
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"

/******************************************************************************
Constants
******************************************************************************/
/* String constants used for screen output far since they are outside 
   64k boundary */
_far const char cmd_clr_scr[] = {27,'[','2','J',0};
_far const char cmd_cur_home[] = {27,'[','H',0};

/******************************************************************************
Global variables
******************************************************************************/
/* Input 16 � 16-bit data matrix for X-Y ram conversion */
const unsigned short _far xy_Inputbuff [16] = {0x0000, 
	0x0ff0, 0x0810, 0x0810,  0x0810, 0x0020, 0x0020, 0x0040, 0x0040, 
	0x0080, 0x0080, 0x0080, 0x0100, 0x0100, 0x0100, 0x0000};  

/* Output 16 � 16-bit data matrix for X-Y ram conversion */
static unsigned short xy_Outputbuff [16];

/* Flag shared between interrupt handler and transmit routine */
static unsigned char interruptFlag = 1;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routines for UART0 and  
				  X-Y ram conversion operation.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void main(void)				
{
	/* SW3 connected to INT2n and configured as follows 
	Interrupt Control Register for INT2
	b2:b0 	- ILVL2:ILVL0 	- 011 (Interrupt priority 3 selected for INT2)
	b3 		- IR		 	- 0   (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0   (Polarity select bit. Falling edge selected.)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	
	int2ic = 0x03;
	
	/* Enable Interrupts */
	ENABLE_IRQ
	
	/* UART initialization */
	uart0_init();
	
	/* X-Y Conversion initialization */ 
	xy_init();
		
	/* Transmit input and rotated 16 � 16 matrix buffer on UART */
	transmit_buff();
	
	/* End of the user program. This function must not exit. */
	while(1);
}
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: xy_init
* Description 	: X-Y conversion configuration 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void xy_init(void)
{
	/* Read mode set bit. Data rotation */
	xyc0 = 0;
	
	/* Write Mode Set Bit. No bit position reverse */ 
	xyc1 = 0;
	
	/* Write the 16 � 16-bit matrix to Xi Register */
	x0r = (short)xy_Inputbuff[0];
	x1r = (short)xy_Inputbuff[1];
	x2r = (short)xy_Inputbuff[2];
	x3r = (short)xy_Inputbuff[3];
	x4r = (short)xy_Inputbuff[4];
	x5r = (short)xy_Inputbuff[5];
	x6r = (short)xy_Inputbuff[6];
	x7r = (short)xy_Inputbuff[7];
	x8r = (short)xy_Inputbuff[8];
	x9r = (short)xy_Inputbuff[9];
	x10r = (short)xy_Inputbuff[10];
	x11r = (short)xy_Inputbuff[11];
	x12r = (short)xy_Inputbuff[12];
	x13r = (short)xy_Inputbuff[13];
	x14r = (short)xy_Inputbuff[14];
	x15r = (short)xy_Inputbuff[15];
	
	/* Read the 90 degrees rotated data in xy_Outputbuff */
	xy_Outputbuff[0] = (unsigned short)y0r;	 
	xy_Outputbuff[1] = (unsigned short)y1r;			
	xy_Outputbuff[2] = (unsigned short)y2r;
	xy_Outputbuff[3] = (unsigned short)y3r;
	xy_Outputbuff[4] = (unsigned short)y4r;
	xy_Outputbuff[5] = (unsigned short)y5r;
	xy_Outputbuff[6] = (unsigned short)y6r;
	xy_Outputbuff[7] = (unsigned short)y7r;
	xy_Outputbuff[8] = (unsigned short)y8r;
	xy_Outputbuff[9] = (unsigned short)y9r;
	xy_Outputbuff[10] = (unsigned short)y10r;
	xy_Outputbuff[11] = (unsigned short)y11r;
	xy_Outputbuff[12] = (unsigned short)y12r;
	xy_Outputbuff[13] = (unsigned short)y13r;
	xy_Outputbuff[14] = (unsigned short)y14r;
	xy_Outputbuff[15] = (unsigned short)y15r;
}
/******************************************************************************
End of function xy_init
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: uart0_init
* Description 	: UART configuration - BAUD - 19200, 8 data bits, 1 stop bit,
*				  no parity.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void uart0_init(void) 
{
	/* Set UART0 bit rate generator bit rate can be calculated by:	
		bit rate = ((BRG count source / 16)/baud rate) - 1
		Baud rate is based on main crystal / PLL */
	u0brg = (f1_CLK_SPEED / 16 / 19200) - 1;	
	
	/* UART0 transmit/receive mode register 
	  b2:b0	- SMD2:SMD0	 - 101 (UART mode with character bit 
	  							length is 8 bits selected)
   	  b3	- CKDIR		 - 0 (Internal clock selected)
   	  b4	- STPS		 - 0 (1 Stop bit)
   	  b5	- PRY		 - 0 (No parity used)
   	  b6	- PRYE		 - 0 (No parity used)
  	  b7	- IOPOL		 - 0 (TXD, RXD polarity not inverted) 	*/
	
	u0mr = 0x05;		
	
	/* UART0 transmit/receive control register 0 
	  b1:b0	- CLK01:CLK0 - 00 (f1 clock selected)
   	  b2 	- Reserved 	 - 0 
  	  b3	- TXEPT		 - 0 (Clear transmit register empty flag)
   	  b4	- CRD		 - 1 (Disable CTS/RTS function)
   	  b5	- NCH		 - 0 (Pins TXDi/SDAi and SCLi are push-pull output)
   	  b6	- CKPOL		 - 0 (Transmit data is output at the falling edge of
	  						 transmit/receive clock and receive data is input at
							 the rising edge
  	  b7	- UFORM		 - 0 (LSB first selected) */

  	u0c0 = 0x10; 		

	/* Dummy read of UART0 receive buffer */
	u0tb = u0rb;		
	
	/* Clear UART0 transmit buffer */
  	u0tb = 0;			

	/* pin settings for making pin p6_3 as transmitter pin of UART0 */
	p6_3s = 0x03;
	
	/* pin settings for making pin p6_2 as transmitter pin of UART0 */            
	pd6_3 = 1;
 
    /* pin settings for making pin p6_2 as receiver pin of UART0 */
	pd6_2 = 0;
	
	/* UART0 transmit/receive control register 1 
	b0 		- TE		- 1 (Enable transmission)	
	b1	 	- TI 		- 0 (Clear the 'transmit buffer empty' flag)
	b2 		- RE 		- 0 (Enable reception)
	b3 		- RI		- 0 (Clear the 'Receive complete' flag)
	b4 		- U0IRS		- 0 (U0TB register is empty)
	b5		- U0RRM		- 0 (Continuous receive mode disabled)
	b6		- UOLCH		- 0 (Data non logic-inverted)
	b7		- Reserved  - 0 */

	u0c1 = 0x01; 		
}
/******************************************************************************
End of function uart0_init
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: transmit_buff
* Description 	: This function converts 16 � 16-bit matrix variables 
*				  'xy_Inputbuff' and 'xy_Outputbuff' in binay format  
* Argument  	: none 
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void transmit_buff(void)
{
	unsigned char outCnt, bitCnt;
	
	/* Stores the bit representation of 16 bit number */
	unsigned char bit_array[17];
	
	/* Variable stores intermediate result */ 
	unsigned short temp; 
	
	/* Text to be displayed at the beginning of the program output
   	to the terminal window (\r\n = carriage return & linefeed) */
	text_write(cmd_clr_scr);	 	
	text_write(cmd_cur_home);	 	
	text_write("Renesas Technology Corporation \r\n");	   
	text_write("RSKR32C111 X-Y conversion demo. \r\n");	
	text_write("Input 16 * 16-bit matrix is \r\n");
	
	/* Transmit input 16 � 16-bit matrix buffer */ 
	for (outCnt = 0; outCnt < 16; outCnt++)
	{
		/* Bit conversion */
		for (bitCnt = 0; bitCnt < 16; bitCnt++)
		{
			/* Stores intermediate result */
			temp = bitCnt;
			
			/* Get the binary '1' or '0' value */ 
			if ((xy_Inputbuff[outCnt]) & (1U << temp))
			{
				/* Store ascii 1 into array */
				bit_array[15 - bitCnt] = '1';
			}

			else
			{
				/* Store ascii 0 into array */
				bit_array[15 - bitCnt] = '0';
			}
		}
			
		/* Add NULL Character */
		bit_array[bitCnt] = '\0';
			
		/* Transmit the bit array */
		text_write ((char *)bit_array);
		text_write("\r\n");
	}
	
	/* Display message */
	text_write("\r\nPlease press Switch 3 (SW3) to view X-Y conversion result\r\n");
	
	while (interruptFlag)
	{
		/* Wait till user presses SW3 */
	}
	
	text_write("\r\nOutput 16-bit matrix is \r\n");
	
	/* transmit output 16 � 16-bit matrix buffer */ 
	for (outCnt = 0; outCnt < 16; outCnt++)
	{
		/* Bit conversion */
		for (bitCnt = 0; bitCnt < 16; bitCnt++)
		{
			/* Stores intermediate result */
			temp = bitCnt;
			
			/* Get the binary '1' or '0' value */ 
			if ((xy_Outputbuff[outCnt]) & (1U << temp))
			{
				/* Store ascii 1 into array */
				bit_array[15 - bitCnt] = '1';
			}
			else
			{
				/* Store ascii 0 into array */
				bit_array[15 - bitCnt] = '0';
			}
		}
			
		/* Add NULL Character */
		bit_array[bitCnt] = '\0';
		
		/* Transmit the bit array */
		text_write ((char *)bit_array);
		text_write("\r\n");
	}
}
/******************************************************************************
End of function transmit_buff
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: text_write
* Description 	: This function sends a text string to the terminal program  
* Argument  	: (const char *) msg_string -> the text string to output
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void text_write (_far const char * msg_string)
{
	/* Variable used to refer specific data while reading from the message buffer */
	char i;
	
	/* This loop reads a text string from the buffer and loads it to the UART0
	   transmit buffer */
	for (i = 0; msg_string[i]; i++)
	{	 
		while(ti_u0c1 == 0)
		{
			/* Wait till the previous transmission completes */					
		}

		/* Output the character on the serial port. */ 
		u0tb = (short)msg_string[i];
	}
}
/******************************************************************************
End of function text_write
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _int2
* Description 	: Interrupt Handler for INT2. SW3 is connected to INT2
*				  interrupt pin
* Argument  	: none
* Return value  : Resets 'interruptFlag' global variable.
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt	_int2(vect=29)
void _int2(void)
{
	interruptFlag = 0;
}
/**********************************************************************************
End of ISR _int2
***********************************************************************************/

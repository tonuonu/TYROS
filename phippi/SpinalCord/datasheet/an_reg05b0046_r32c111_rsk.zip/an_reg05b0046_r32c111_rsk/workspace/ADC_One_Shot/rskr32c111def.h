/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: rskr32c111def.h
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Defines for RSKR32C111 starter kit
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

#ifndef RSKR32C111DEF_H
#define RSKR32C111DEF_H

/******************************************************************************
Macro Defines
*******************************************************************************/
/* Peripheral Clock Speed = 25 MHz */
#define	f1_CLK_SPEED	(25000000)

/* Port pins having switch connected	*/
#define	SW1 			p8_2
#define SW2 			p8_3
#define SW3 			p8_4

#define SW1_DDR			pd8_2
#define SW2_DDR			pd8_3
#define SW3_DDR			pd8_4

/* Port pins having LEDs connected	*/
#define	LED0			p4_0
#define	LED1			p4_1
#define	LED2			p4_2
#define	LED3			p4_3

#define	LED0_DDR		pd4_0
#define	LED1_DDR		pd4_1
#define	LED2_DDR		pd4_2
#define	LED3_DDR		pd4_3

#define LED_ON      	0
#define LED_OFF     	1

/* LED port settings */
/* LED Port data register */
#define LED_PORT_DR		p4

/* Port bit to toggle for flashing LED */
#define LED_BIT			(0x0F)

#define LEDS_ON			(0x00)
#define LEDS_OFF		(0x0F)
#define SET_BIT_HIGH	(1)
#define SET_BIT_LOW		(0)
#define SET_BYTE_HIGH	(0xFF)
#define SET_BYTE_LOW	(0x00)

/* Common Defines */
#define TRUE    		1
#define FALSE   		0

/* Interrupt control (i.e. Enable / Disable) */
#define ENABLE_IRQ   	{_asm("FSET I");}
#define DISABLE_IRQ		{_asm("FCLR I");}

/* 1 cycle delay	*/
#define	NOP()			{_asm("nop");}

#endif 		

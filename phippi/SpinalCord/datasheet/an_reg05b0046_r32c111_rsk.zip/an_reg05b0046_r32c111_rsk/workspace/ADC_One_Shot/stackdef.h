/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: stackdef.h
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Defines user and interrupt stack size
*******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

#ifndef STACKDEF_H
#define STACKDEF_H

 /* Define the size of stack
   When you change the size of stack, modify these lines.
   specify stacksize using -D option. */

#ifndef __STACKSIZE__
#pragma STACKSIZE	0x300UL
#else
#pragma STACKSIZE	__STACKSIZE__
#endif
#ifndef __ISTACKSIZE__
#pragma ISTACKSIZE	0x300UL
#else
#pragma ISTACKSIZE	__ISTACKSIZE__
#endif

/******************************************************************************
Extern Variable Declarations
******************************************************************************/
extern unsigned long _stack_top, _istack_top;

#endif


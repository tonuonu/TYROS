/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: fvector.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Defines the fixed vector table.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* This header file contains addresses of the interrupt vectors */
#include "vector.h"

/******************************************************************************
Interrupt vectors
******************************************************************************/
/* The following '#pragma sectaddress' directive instructs the linker to
assign a address 0xffffffdc to the section "fvector". This has been used to format
the fixed vector table. */

#pragma sectaddress	fvector,ROMDATA FVECTADDR

/* The directive #pragma interrupt functionname instructs the compiler to treat
the following function as an interrupt. The compiler will save all registers
used in the function and replace the normal RTS instruction with an REIT
instruction at the end of the function. "/v" requests to generate a vector 
table for fixed vector.*/

/* udi */
#pragma interrupt/v _dummy_int	

/* over_flow */
#pragma interrupt/v _dummy_int	

/* brki */
#pragma interrupt/v _dummy_int	

/* cpu id code */
#pragma interrupt/v  0xffffffff	

/* cpu id code */
#pragma interrupt/v  0xffffffff	

/* wdt */
#pragma interrupt/v _dummy_int	

/* dbc */
#pragma interrupt/v _dummy_int	

/* nmi */
#pragma interrupt/v _dummy_int

/* Power on reset	*/
#pragma interrupt/v start

/* Dummy function which can be used where no other user function is defined. */
#pragma interrupt _dummy_int()
void _dummy_int(void)
{
	/* Empty Function	*/	
}


/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: resetprg.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Reset program
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Program Code
******************************************************************************/
/* This header file contains the macro defines & inline functions used in this
   file	*/
#include "resetprg.h"
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/* Following header file provides prototypes for hardware configuration
   functions. */
#include "hwsetup.h"
/* This header file contains addresses of the interrupt vectors */
#include "vector.h"
/* Following header file contains macro defines for initializing the sections. */
#include "initsct.h"

/******************************************************************************
Global variables
******************************************************************************/
unsigned long _flg_;
unsigned long * _sb_;
unsigned long * _fb_;
unsigned long *_sp_;
unsigned long *_isp_;
unsigned long *_intb_;

/******************************************************************************
User Program Code
******************************************************************************/

/* Note: The #pragma entry directive used below specifies the power on reset
function. Linker uses this information while relocating the code in ROM. */

/* Note: The #pragma SECTION directive used below instructs the linker to
assign a new section name to a section. 
The format of this directive is as follows - 
#pragma SECTION. section name. new section name  */

#pragma entry start
#pragma section program interrupt 

/*��FUNC COMMENT��*************************************************************
* Outline 		: start
* Description 	: Reset program 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void start(void)
{
	/* Set interrupt stack pointer */
	_isp_	= &_istack_top;	
			
	/* Set flag register */
	_flg_	= 0x0080UL;
					
	/* Set user stack pointer */
	_sp_	= &_stack_top;
				 
	/* 400H fixation (Do not change) */
	_sb_	= (unsigned long *)0x400UL;	 
	_asm("	fset	b");
	_sb_	= (unsigned long *)0x400UL;
	_asm("	fclr	b");
	
	/* Set variable vector's address */
	_intb_ = (unsigned long *)VECTOR_ADR;
	
	/* Initialize each sections */
	initsct();	
	
#ifdef __HEAP__
	/* Initialize heap  */
	heap_init();	
#endif

	/* Initialize FB register for debugger */
	_fb_ = 0U;	
	
	/* Initialize standard I/O */
	HardwareSetup();	
	
	/* Call main routine */
	main();		
	
	/* Infinite loop */
	_exit();	
}
/******************************************************************************
End of function start
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _exit
* Description 	: Exit program 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void _exit(void)
{
	while(1)
	{
		/* This loop will never exit. */ 		
	}
}
/*****************************************************************************
End of function _exit
******************************************************************************/

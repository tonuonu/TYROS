/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: lcd.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description   : LCD Module utility functions.
*				  Written for KS0066u compatible LCD Module.
*	    		  (8 characters by 2 lines)
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/* Following header file provides function prototypes for LCD controlling
   functions & macro defines */
#include "lcd.h"

/**********************************************************************************
User Program Code
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: InitialiseDisplay
* Description 	: Initializes the LCD display. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void InitialiseDisplay(void)
{
	/* Power Up Delay for LCD Module */
	EN_PIN = SET_BIT_HIGH;
	DisplayDelay(7000);
	EN_PIN = SET_BIT_LOW;

	/* Display initialises in 8 bit mode - so send one write (seen as 8 bit)
	to set to 4 bit mode. */
	/* Function Set */
	LCD_nibble_write(CTRL_WR,0x03);
	LCD_nibble_write(CTRL_WR,0x03);
	DisplayDelay(39);
 
	/* Configure display */
	LCD_nibble_write(CTRL_WR,0x03);
	LCD_nibble_write(CTRL_WR,0x02);
	LCD_nibble_write(CTRL_WR,(LCD_DISPLAY_ON | LCD_TWO_LINE ));
	LCD_nibble_write(CTRL_WR,(LCD_DISPLAY_ON | LCD_TWO_LINE ));
	DisplayDelay(39);

	/* Display ON/OFF control */
	LCD_write(CTRL_WR,LCD_CURSOR_OFF);
	DisplayDelay(39);

	/* Display Clear */
	LCD_write(CTRL_WR,LCD_CLEAR);
	DisplayDelay(1530);

	/* Entry Mode Set */
	LCD_write(CTRL_WR,0x06);
	LCD_write(CTRL_WR,LCD_HOME_L1);
}
/******************************************************************************
End of function InitialiseDisplay
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: DisplayString
* Description 	: This function controls LCD writes to line 1 or 2 of the LCD.
*                 You need to use the defines LCD_LINE1 and LCD_LINE2 in order
*				  to specify the starting position.
*				  For example, to start at the 2nd position on line 1...
*				   		DisplayString(LCD_LINE1 + 1, "Hello") 
* Argument  	: (unsigned char)position -	Line number of display 
*			      (const char *) string -	Pointer to data to be written to display.
*			    	           		Last character should be null.
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void DisplayString(unsigned char position, _far const char * string)
{
	static unsigned char next_pos = 0xFF;

	/* Set line position if needed. We don't want to if we don't need 
	   to because LCD control operations take longer than LCD data
	   operations. */
	if( next_pos != position)
	{
		if(position < LCD_LINE2)
		{
			/* Display on Line 1 */
		  	LCD_write(CTRL_WR, ((char)(LCD_HOME_L1 + position)));
		}
		else
		{
			/* Display on Line 2 */
		  	LCD_write(CTRL_WR, ((char)((LCD_HOME_L2 + position) - LCD_LINE2)));
		}
		/* set position index to known value */
		next_pos = position;		
	}

	do
	{
		LCD_write(DATA_WR,*string++);
		
		/* increment position index */
		next_pos++;				
	} 
	while(*string);
}
/******************************************************************************
End of function DisplayString
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: LCD_write
* Description 	: This function controls LCD writes to line 1 or 2 of the LCD.
*                 You need to use the defines LCD_LINE1 and LCD_LINE2 in order
*				  to specify the starting position.
*				  For example, to start at the 2nd position on line 1...
*				   		DisplayString(LCD_LINE1 + 1, "Hello") 
* Argument  	: (unsigned char)value - the value to write
*				  (char) data_or_ctrl - To write value 
*					as DATA or CONTROL
*						1 = DATA
*						0 = CONTROL
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void LCD_write(unsigned char data_or_ctrl, char value)
{
	/* Write upper nibble first */
	LCD_nibble_write(data_or_ctrl, (char)(value & 0xF0) >> 4);
	
	/* Write lower nibble second */
	LCD_nibble_write(data_or_ctrl, (value & 0x0F));
}
/******************************************************************************
End of function LCD_write
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: LCD_nibble_write
* Description 	: Writes data to display. Sends command to display. 
* Argument  	: (unsigned char) value - the value to write
*				  (char) data_or_ctrl - To write value  
*				    as DATA or CONTROL
*						1 = DATA
*						0 = CONTROL
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void LCD_nibble_write(unsigned char data_or_ctrl, char value)
{
	char ucStore;
	
	/* Set Register Select pin high for Data */
	if (data_or_ctrl == DATA_WR)
	{
		RS_PIN = SET_BIT_HIGH;
	}
	else
	{
		RS_PIN = SET_BIT_LOW;
	}
	
	/* There must be 40ns between RS write and EN write */
  	DisplayDelay(1);					
	
  	/* EN enable chip (HIGH) */
	EN_PIN = SET_BIT_HIGH;
	
	/* Tiny delay */  			
  	DisplayDelay(1);
	
	/* Clear port bits used */	
	ucStore = DATA_PORT;
	ucStore &= (char) ~DATA_PORT_MASK;
	
	/* OR in data */	
	ucStore |= (char) ((value << DATA_PORT_SHIFT) & DATA_PORT_MASK );
	
	/* Write data to port */	
	DATA_PORT = ucStore;
	
	/* write delay while En High */	            
	DisplayDelay(20);
	
	/* Latch data by dropping EN */					
    EN_PIN = SET_BIT_LOW;
	
	/* Data hold delay */				
	DisplayDelay(20);					
	
	if (data_or_ctrl == CTRL_WR)
	{
		/* Extra delay needed for control writes */
		DisplayDelay(0x7FF);
	}				
}
/******************************************************************************
End of function LCD_nibble_write
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: DisplayDelay
* Description 	: Delay routine for LCD display.  
* Argument  	: (unsigned long) units - in microseconds
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void DisplayDelay(unsigned long units)
{
	unsigned long counter = units * DELAY_TIMING;
	
	while(counter--)
	{
		/* Delay Loop	*/
		NOP()
	}
}
/******************************************************************************
End of function DisplayDelay
******************************************************************************/
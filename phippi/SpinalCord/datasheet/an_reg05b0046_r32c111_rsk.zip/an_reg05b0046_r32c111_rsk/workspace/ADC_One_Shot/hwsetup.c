/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: hwsetup.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Contains hardware setup functions
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/* Following header file provides prototypes for hardware configuration
   functions. */
#include "hwsetup.h"

/******************************************************************************
User Program Code Prototypes
******************************************************************************/
/* These functions are private so their prototypes are defined locally */
static void ConfigureOperatingFrequency(void);
static void EnablePeripheralModules(void);
static void ConfigurePortPins(void);

/******************************************************************************
User Program Code 
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: HardwareSetup
* Description 	: Sets up the hardware.
*   			  This function calls the hardware initialization functions to
*				  configure the CPU operating frequency, port pins & required
*				  on-chip modules in order to setup the RSK for the main
*				  application.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void HardwareSetup(void)
{    
	/* Configures CPU clock	*/
	ConfigureOperatingFrequency();

	/* Configures port pins	*/
	ConfigurePortPins();

	/* Enables required on-chip peripherals	*/
	EnablePeripheralModules();
}
/******************************************************************************
End of function HardwareSetup
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: ConfigureOperatingFrequency
* Description 	: Sets up operating speed and configures the main & sub-clock.
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

static void ConfigureOperatingFrequency(void)
{
    unsigned short i;
  
	/* Enable writing to the CCR register */
	prr = 0xAA;
	
	/* Clock Control Register (CCR) 
	b1:b0		- BCD1:BCD0		- 11 (Base Clock = PLL Clock / 2)
	b3:b2 		- CCD1:CCD0		- 11 (CPU Clock = Base Clock (No Division)) 
	b5:b4		- PCD1:PCD0		- 01 (Peripheral Bus Clock = Base Clock / 2)
	b6			- Reversed		- 0
	b7			- BCS			- 0 (PLL clock) */
	ccr = 0x1F;
	
	/* Disable writing to the CCR register */
	prr = 0x00;

	/* Enable writing to PM3 */
	prc0=1;
	
	/* Processor Mode Register 3 (PM3)
	b4:b3:b2:b1:b0	- Reserved	- 00000
	b6:b5			- PM36:PM35	- 10 (Peripheral Clock Source = PLL Clock / 4)
	b7				- Reserved	- 0 */
	pm3 = 0x40;
	
	/* Disable writing to PM3 */
	prc0=0;
	
	/* Enable writing to PLC0 and PLC1 */
	prc2 = 1;
	
    /* Set the internal clocks as follows 
	PLL Clock = 16 MHz * 6.25 = 100 MHz
	Base Clock = PLL Clock (100 MHz) / 2 = 50 MHz
	CPU Clock = Base Clock = 50 MHz  
	Peripheral Bus Clock = Base Clock (50 MHz) / 2 = 25 MHz
	Peripheral Clock Source = PLL Clock (100 MHz) / 4 = 25 MHz	
	
	Use a 16-bit write instruction to modify plc0 and plc1 at the same time. 
	
	PLL Control Register 0 (PLC0)
	b4:b3:b2:b1:b0	- MCV4:MCV3:MCV2:MCV1:MCV0	- 00100 (Set plc0 to 04)
	b7:b6:b5		- SCV2:SCV1:SCV0			- 000   
	
	PLL Control Register 1 (PLC1)
	b3:b2:b1:b0		- RCV3:RCV2:RCV1:RCV0		- 0011 (Set plc1 to 03)
	b4				- SEO						- 0    (PLL mode)
	b7:b6:b5		- Reserved					- 000 */
		 
	*(unsigned short *)&plc0 = 0x0304; 
	
	/* Disable writing to PLC0 and PLC1 */
	prc2 = 0;

	for (i=0; i<0x8000u;i++)
	{
		/* Add delay for PLL to stabilise. */
	} 
  
	/* Disable the port pins */
   	pd8_7 = 0;	
   	pd8_6 = 0;
	
	/* Disable the pull-up resistor */
	pu25 = 0;
	
	/* Enable writing to CM0 */
	prc0=1;
	
   	/* Start the 32KHz crystal */
   	cm04 = 1;
	
	/* Disable writing to CM0 */
	prc0=0;
	
	/* Enable writing to PM2 */
	prc1 = 1;
	
	/* Disable clock changes */
	pm21 = 1;
	
	/* Disable writing to PM2 */	
	prc1 = 0;
}
/******************************************************************************
End of function ConfigureOperatingFrequency
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: EnablePeripheralModules
* Description 	: Enables Peripheral Modules before use also enables data flash
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

static void EnablePeripheralModules(void)
{
	/* All modules are active in the R32C device */
}
/******************************************************************************
End of function EnablePeripheralModules
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: ConfigurePortPins
* Description 	: Configures MCU port pins
* Argument 		: none
* Return value 	: none
*��FUNC COMMENT END��*********************************************************/

static void ConfigurePortPins(void)
{
	/* Port pins default to inputs. To ensure safe initialisation set 
	the pin states before changing the data direction registers. This 
	will avoid any unintentional state changes on the external ports.
	Many peripheral modules will override the setting of the port 
	registers. Ensure that the state is safe for external devices if 
	the internal peripheral module is disabled or powered down. */

	/* Switch Port configuration */
	/* All pins are input by default	*/

	/* LED port configuration	*/
	/* Configure the port pins as I/0	*/
	p4_0s = 0;
	p4_1s = 0;
	p4_2s = 0;
	p4_3s = 0;

	/* Turn the LEDs OFF */
	p4 = 0x0F;
	
	/* Configure the port pins connected to LEDs as output. Also make
	 	unused port pins as output	*/
	pd4 = 0xFF;

	/* Debug LCD Port configuration */
	/* Configure the port pins connected to LCD as output	*/
	pd2 = 0xF3;
	p2  = 0x00;

	/* Configure ADPOT	*/
	p10_0s = 0x80;
	pd10_0 = 0;
	
	/* Configure unused pins as output low */
	p0=p1=p3=p5=p7=p8=p9=0x00;       

	/* Configure direction registers as outputs*/
	pd0=pd1=pd3=pd5=0xFF;
	pd8=0x23;
	
	/* To set port9 the direction register must first unprotect register. Do not step
	   or set breakpoints between unprotecting and modifying the direction register */
	
	/* Enable writing to port 9 */	   
	prc2 = 1;
	
	/* Configure the port 9 direction register */
	pd9 = 0xF8;
	
	/* Disable writing to port 9 */	   
	prc2 = 0;
	
	/* Enables & set the CLKOUT pin to output a clock signal with frequency fc */
	/* Enable writing to Processor mode register 0 */
	prc1 = 1;
	
	/* Do not output BCLK. Select the pin function using bits CM01 and 
	   CM00 in the CM0 register */	
	pm07 = 1;
	
	/* Disable writing to Processor mode register 0 */
	prc1 = 0;
	
	/* Enable writing to cm0 register */
	prc0 = 1;
	
	/* set the CLKOUT pin to output a clock signal with frequency fc */
	cm00 = 1;
	cm01 = 0;
	
	/* Disable writing to cm0 register */
	prc0 = 0;
}
/******************************************************************************
End of function ConfigurePortPins
******************************************************************************/

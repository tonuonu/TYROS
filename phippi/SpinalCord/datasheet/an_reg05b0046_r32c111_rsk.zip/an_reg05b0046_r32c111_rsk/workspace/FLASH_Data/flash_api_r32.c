/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: flash_api_r32.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Contains Flash API functions
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/* Following header file provides macro defines & function prototypes 
   used in Flash API functions. */
#include "flash_api_r32c.h"
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"

/******************************************************************************
Global variables 
******************************************************************************/
/* This array contains start addresses of the blocks. */
const unsigned long block_addresses[12] = {0xFFFFFFFEul,0xFFFF7FFEul,0xFFFEFFFEul,
0xFFFE7FFEul,0xFFFDFFFEul,0xFFFCFFFEul,0xFFFBFFFEul,0xFFFAFFFEul,0xFFF9FFFEul,
0xFFF8FFFEul,0x00061FFEul,0x0060FFEul};

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: FlashEraseEW1
* Description 	: Erases an entire flash block.
* Argument  	: (unsigned char) block - The block number to be erasesd 
*				  (BLOCK_0, BLOCK_1, BLOCK_A etc...)
* Return value  : (unsigned char)
*				  0 = Erase Successful
*				  1 = Erase error reported by flash control				  
*��FUNC COMMENT END��**********************************************************/

unsigned char FlashEraseEW1(unsigned char block)
{
	short far * flash_addr;
    unsigned char i, ret_value = 0; 
	short far *command_addr; 

	/* Reduce the CPU speed to 6.25 MHz before entering to CPU re-write mode */
	slowmcuclock();

	/* Get highest even block address */
	flash_addr = (short far *) block_addresses[ block ];
	
	/* Set the command write address	*/
	command_addr = (short *)FLASH_COMMAND_WRITE_ADDR;

	/* Enable writing to the FMCR register */
	prr = 0xAA;
	
	/* Enable CPU rewrite mode */
	few = 1;
	
	/* Disable writing to the FMCR register */
	prr = 0x00;

	/* Enable writing to the FEBC register */
	prr = 0xAA;
	
	/* Configure MPY bits  */
	febc = 0x5AD6; 
	
	/* Disable writing to the FEBC register */
	prr = 0x00;	
	
	/* Enable writing to FMR0 register */
	pr0 = 1;
		
	/* Set EW1 mode */
	ewm = 1;
	
	/* Disable writing to FMR0 register */
	pr0 = 0;

	/* Enable writing to FMR1 register */
	pr0 = 1;

	/* Disable Lock bit protection */
	lbd = 0;
	lbd = 1;

	/* Disable writing to FMR1 register */
	pr0 = 0;

	/* Attempt to erase flash up to 3 times before returning failed */
    for( i = 0; i<3; i++)
    {
		/* Clear status register	*/
		*(short far *)command_addr = 0x0050;		

		/* Send erase command	*/
		*(short far *)command_addr = 0x0020;

		/* Send erase confirm command	*/
		*(short far *)flash_addr = 0x00D0;		

		/* Note: In EW1 Mode, the MCU is suspended until the operation
		   is completed */

        /* Check if operation was successful */
    	if(!eerr)		        
        {
			/* Erasing Successful */
			ret_value = 0;
			break;
        }
		
		/* Three or more extra block erase command should be executed */
	}
		 
 	/* Enable writing to the FMCR register */
	prr = 0xAA;
	
	/* Disable CPU rewrite mode */
	few = 0; 
	
	/* Disable writing to the FMCR register */
	prr = 0x00;
	
	/* Restore the mcu clock	*/
	restoremcuclock();
	
	/* If erro is detected then return 1.	*/
	if (eerr)
	{
		ret_value = 1;
	}
	
	return ret_value;
}
/******************************************************************************
End of function FlashEraseEW1
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: FlashWriteEW1
* Description 	: Writes bytes into flash. 
* Argument  	: flash_addr - Flash address location to be written
*		   		  buffer_addr - data buffer to be written to flash
*				  bytes - The number of bytes to be written
* Return value  : 0 = Operation Successful
*				  1 = Write Error reported by flash control register
*				  2 = Invalid parameter passed
*��FUNC COMMENT END��**********************************************************/

unsigned char FlashWriteEW1(FLASH_PTR_TYPE flash_addr, BUF_PTR_TYPE buffer_addr,
							unsigned short bytes)
{
	unsigned char ret_value = 0;
	unsigned short far *command_addr; 

	/* Reduce the CPU speed to 6.25 MHz before entering to CPU re-write mode */
	slowmcuclock();
	
	command_addr = (unsigned short *)FLASH_COMMAND_WRITE_ADDR;	

	/* Enable writing to the FMCR register */
	prr = 0xAA;
	
	/* Enable CPU rewrite mode */
	few = 1;
	
	/* Disable writing to the FMCR register */
	prr = 0x00;

	/* Enable writing to the FEBC register */
	prr = 0xAA;
	
	/* Configure MPY bits  */
	febc = 0x5AD6; 
	
	/* Disable writing to the FEBC register */
	prr = 0x00;	
	
	/* Enable writing to FMR0 register */
	pr0 = 1;
		
	/* Set EW1 mode */
	ewm = 1;
	
	/* Disable writing to FMR0 register */
	pr0 = 0;

	/* Check that the flash address is on a 8byte boundry	*/	
	if ((unsigned long long)flash_addr % 8)
	{
		ret_value = 2;	
	}
	
	else
	{
		/* Enable writing to the FMCR register */
		prr = 0xAA;
	
		/* Enable CPU rewrite mode */
		few = 1;
	
		/* Disable writing to the FMCR register */
		prr = 0x00;
		
		/* Clear status register	*/
		*(unsigned short far *)command_addr = 0x0050;		

		/* Enable writing to FMR1 register */
		pr0 = 1;

		/* Disable Lock bit protection */
		lbd = 1;

		/* Disable writing to FMR1 register */
		pr0 = 0;	

		while(bytes)
		{
			/*	Send write command	*/
			*(short far *)command_addr = 0x0043;						
			/* R32C/111 writes 8 bytes at a time */
			*(short far *)flash_addr = *(short far *)buffer_addr;	
			(short far *)flash_addr++;
			*(short far *)flash_addr = 0x0000;
			(short far *)flash_addr++; 
			*(short far *)flash_addr = 0x0000;
			(short far *)flash_addr++; 
			*(short far *)flash_addr = 0x0000;

			/* Advance to next flash write address	*/
			flash_addr += 8;			
			/* Advance to next data buffer address	*/
			buffer_addr += 8;			
			/* Subract 8 from byte counter	*/
			bytes -= 8;	
			
			/* Check for program write error */
			if (werr) 
			{
				/* write error */
				ret_value = 1;
				break;
			}
		}
	}

	/* Enable writing to the FMCR register */
	prr = 0xAA;
	
	/* Enable CPU rewrite mode */
	few = 0; 
	
	/* Disable writing to the FMCR register */
	prr = 0x00;

	/* Restore the mcu clock	*/	
	restoremcuclock();
		
	/* return the result */
	return ret_value;
}
/******************************************************************************
End of function FlashWriteEW1
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: slowmcuclock
* Description 	: Reduce the clock speed to 6.25 MHz
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void slowmcuclock(void)
{
	/* variable used to generate delay	*/
	unsigned long delay;
	
	/* Configure the clock */
	/* Enable writing to PM2 register */
	prc1 = 1;
	
	/* Protect the clock by the PRCR register */
	pm21 = 0;
	
	/* Enable writing to CCR register */
	prr = 0xAA;
	
	/* Clock Control Register (CCR) 
	b1:b0		- BCD1:BCD0		- 01 (Base Clock = PLL Clock / 4)
	b3:b2 		- CCD1:CCD0		- 10 (CPU Clock = Base Clock/4) 
	b5:b4		- PCD1:PCD0		- 11 (Peripheral Bus Clock = Base Clock / 4)
	b6			- Reversed		- 0
	b7			- BCS			- 0 (PLL clock) */

	ccr = 0x39;
	
	/* Disable writing to CCR register */
	prr = 0;
	
	/* Disable clock changes */
	pm21 = 1;

	/* Enable writing to PM2 register */
	prc1 = 0;
	
	for (delay=0; delay<0x8000u;delay++)
	{
		/* Add delay for PLL to stabilise. */
	} 	
}
/******************************************************************************
End of function FlashWriteEW1
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: restoremcuclock
* Description 	: Restore the mcu clock to 50 MHz
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void restoremcuclock(void)
{
	/* variable used to generate delay	*/
	unsigned long delay;

	/* Configure the clock */
	/* Enable writing to PM2 register */
	prc1 = 1;
	
	/* Protect the clock by the PRCR register */
	pm21 = 0;
	
	/* Enable writing to CCR register */
	prr = 0xAA;
	
	/* Clock Control Register (CCR) 
	b1:b0		- BCD1:BCD0		- 11 (Base Clock = PLL Clock / 2)
	b3:b2 		- CCD1:CCD0		- 11 (CPU Clock = Base Clock (No Division)) 
	b5:b4		- PCD1:PCD0		- 01 (Peripheral Bus Clock = Base Clock / 2)
	b6			- Reversed		- 0
	b7			- BCS			- 0 (PLL clock) */

	ccr = 0x1F;
	
	/* Disable writing to CCR register */
	prr = 0;
	
	/* Disable clock changes */
	pm21 = 1;

	/* Enable writing to PM2 register */
	prc1 = 0;
	
	for (delay=0; delay<0x8000u;delay++)
	{
		/* Add delay for PLL to stabilise. */
	} 	
}
/******************************************************************************
End of function restoremcuclock
******************************************************************************/

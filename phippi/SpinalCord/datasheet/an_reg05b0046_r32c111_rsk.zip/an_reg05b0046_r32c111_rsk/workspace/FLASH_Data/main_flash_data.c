/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_flash_data.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Demonstrates use of Flash API functions to erase & program
*				  the data flash
* Operation:
*  			1. Build this application and download it to target. Press 'Reset Go'.
*			2. Click on the 'Memory' window available at following menu location -
*				View -> CPU -> Memory
*			3. Enter following settings for the memory window -
*				Display Address 	 - 0x60000
* 				Scroll Start Address - 0x60000
*				Scroll End Address 	 - 0x61FFF
*			   Click 'OK'.
*			4. Please set the memory window in 8 bytes mode, as this device
*			   supports 8 byte write operation.
*  			5. The application name "FLASH RW" will be shown on the debug LCD.
*  			6. Press SW1 to get the current ADC value and write it to FLASH memory. 
*			   The FLASH pointer is incremented once when SW1 is pressed and ADC
*			   value is stored at that FLASH memory location.
*			7. Proceed to step-8 to see the stored ADC value "or" proceed to
*			   step-9 to clear the Flash memory.
*			8. Press Stop in the HEW window to see the ADC values sotred in the
* 			   Flash memory location.
*			9. Bypass step 8 and Press SW3 to clear FLASH memory.
*
* NOTE:	
*		1. Please select "Debugging of CPU rewrite mode" option in the "Emulator
* 		   Mode" tab while downloading this applicatin to the target.
*		2. When "Debugging of CPU rewrite mode" option is selected, it is advised
*		   to use eventpoints instead of breakpoints.
*		3. The debugger may loose control over the target if this application
*		   is rebuild & download when the CPU is in CPU rewrite mode with the clock
*		   settings changed to suit the CPU rewrite mode.
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main_flash_data.h"
/* Following header file provides function prototypes for LCD controlling
   functions & macro defines */
#include "lcd.h"
/* Following header file provides macro defines & function prototypes 
   used in Flash API functions. */
#include "flash_api_r32c.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"

/********************************************************************************
Global variables
********************************************************************************/
/* This variable stores the ADC result */
short usADC_Result;
/* The pointer to the current address of FLASH */
unsigned short pAddress;
/* This is the buffer for ADC bin to string of HEX conversion */
char adc_buffer[8];
/* This is the buffer for Flash pointer binary to string of HEX conversion */
char p_buffer[8];
/* Data to be written in flash	*/
unsigned long long ul_fdata;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization functions for ADC
*				  & debug LCD. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void main(void)				
{
	/* Initialize the variables used. */
	usADC_Result = 0;
	pAddress = 0;
	
	/* Call the block erase function to erase the data flash block-B */	
	if (FlashEraseEW1(BLOCK_B) != 0)
	{
		/* Flash erase erro detected. This loop will never exit.	*/
		while (1) 
		{
			DisplayString(LCD_LINE1, "ERASE   ");
			DisplayString(LCD_LINE2, "ERROR   ");
		}
	}

	/* Call the block erase function to erase the data flash block-A */	
	if (FlashEraseEW1(BLOCK_A) != 0)
	{
		/* Flash erase erro detected. This loop will never exit.	*/
		while (1) 
		{
			DisplayString(LCD_LINE1, "ERASE   ");
			DisplayString(LCD_LINE2, "ERROR   ");
		}
	}
	
	/* Configure the ADC in oneshot mode */
	Init_ADC();
 	
	/* Initialize the debug LCD */
	InitialiseDisplay();

	/* Display the application name on LCD. */
	DisplayString(LCD_LINE1,"FLASH RW");
	
	/* Send pAddress to the debug LCD */
	Send_ptr_LCD();
	
	/* Disable interrupts	*/
	DISABLE_IRQ
	
	while (1)
	{
		/* Check if, SW1 is pressed */
		if (SW1 == 0)
		{
			/* Read ADC value */
			Get_ADC();
			
			/* Write ADC result in on-chip FLASH memory */
			Write_FLASH();
			
			/* Display the ADC result on the debug LCD */
			DisplayString(LCD_LINE1, adc_buffer);
			
			/* Display the pointer to the current flash memory location on the
			   debug LCD */
			Send_ptr_LCD();
			
			while (SW1 == 0)
			{
				/* Wait here till the user releases the switch */
			}
		}
		
		/* If SW3 is pressed Erase FLASH ROM */
		if (SW3 == 0)
		{
			/*	Call the Flash API function to erase the required data flash
				block-B */
			if (FlashEraseEW1(BLOCK_B) != 0)
			{				
				while (1)
				{
					/* Wait forever if error is occured */
					DisplayString(LCD_LINE1, "ERASE   ");
					DisplayString(LCD_LINE2, "ERROR   ");					
				}
			}
			
			/*	Call the Flash API function to erase the required data flash
				block-A */
			if (FlashEraseEW1(BLOCK_A) != 0)
			{				
				while (1)
				{
					/* Wait forever if error is occured */
					DisplayString(LCD_LINE1, "ERASE   ");
					DisplayString(LCD_LINE2, "ERROR   ");					
				}
			}
			
			/* Set address at the beginning of the FLASH memory */
			pAddress = 0;
			
			/* Send pAddress to the on-board debug LCD */
			Send_ptr_LCD();
			
			while (SW3 == 0)
			{
				/* Wait here till the user releases the switch */
			}
		}
	}
}         
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: Write_FLASH
* Description 	: Writes data to FLASH memory. Halts in case of memory overflow
* 				  or any other write error. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void Write_FLASH(void)
{
	/* Call the Flash API function to program the flash memory. */
	if (FlashWriteEW1((FLASH_PTR_TYPE)(D_FLASH_START+pAddress), 
					(BUF_PTR_TYPE)&ul_fdata, sizeof(ul_fdata)) != 0)
		{
			/* A nonzero value returned by the function above indicates program
			   error */
			DisplayString(LCD_LINE1, "PROGRAM ");
			DisplayString(LCD_LINE2, "ERROR   ");	
						
			while (1)
			{
				/* Halt the application here to indicate program error. */
			}
		}
	
	/* Set pointer to the next address */
	pAddress += (unsigned short) (sizeof(ul_fdata));
	
	/* Check for address overflow	*/
	if(pAddress >= 0x1000)
	{
		/* Reset the address	*/
		pAddress = 0;
	}
}
/*******************************************************************************
End of function Write_FLASH
*******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: Get_ADC
* Description 	: Reads the current ADC value and converts it to string
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void Get_ADC(void)
{
	/* Start AD conversion */
	adst_ad0con0 = 1;
	
	while (ir_ad0ic == 0) 
	{
		/* Wait until AD conversion is finished */
	}
	
	/* Clear ADC complete flag */
	ir_ad0ic = 0;
	
	/* Save the ADC result */
	usADC_Result = ad00;

	/* Copy the result into 'ul_fdata' variable which will be passed to the flash
	   API function for writing to the flash memory. */
	ul_fdata = (unsigned long long)usADC_Result;

	/* Convert the ADC result to display on the LCD */
	Convert_ADC_To_String((unsigned short)usADC_Result, adc_buffer);
}
/*******************************************************************************
End of function Get_ADC
*******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: Send_ptr_LCD
* Description 	: Displays the current pointer to the FLASH memory address to LCD
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void Send_ptr_LCD(void)
{
	/* Convert the pointer data into string & display it on the LCD. */
	Convert_Ptr_To_String((D_FLASH_START + pAddress), p_buffer);
	DisplayString(LCD_LINE2, p_buffer);
}

/*******************************************************************************
End of function Send_ptr_LCD
********************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: Init_ADC
* Description 	: Configures the ADC channel 0 in oneshot mode, software triggered
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void Init_ADC(void)
{
	/* ADC conversion start flag. Set to 0 to stop ADC conversion */
	adst_ad0con0 = 0;
	
	/* ADC Control Register 0 
	b2:b1:b0	- CH2:CH1:CH0	- 000 (Analog Input Pin Select Bit. AN0 selected)
	b4:b3		- MD1:MD0		- 00  (ADC One-shot mode)
	b5			- TRG			- 0   (Software trigger)
	b6			- ADST			- 0   (AD conversion stopped)
	b7			- CKS0			- 1	  (Frequency select bit. fAD�1 selected) */
	
	ad0con0 = 0x10;
	
	/* ADC Control Register 1
	b1:b0	- SCAN1:SCAN0	- 00 (AN0 selected)
	b2		- MD2			- 0  (single sweep mode)
	b3		- BITS			- 1  (10 bit mode)
	b4		- CKS1			- 1  (Frequency select bit. fAD�1 selected)
	b5		- VCUT 			- 1  (VREF connected)
	b7:b6	- OPA1:OPA0		- 00 (Not Applicable in this mode) */				
	
	ad0con1 = 0x38;
	
	/* ADC Control Register 2 
	b0		- SMP			- 1  (With sample & hold function)
	b2:b1	- APS1:APS0		- 00 (AN0 selected)
	b4:b3	- Reserved		- 00
	b5		- TRG0			- 0  (Not applicable in software trigger mode)
	b7:b6	- Reserved		- 00 */
	
	ad0con2 = 0x01;
	
	/* ADC Control Register 3
	b0			- DUS			- 0 (DMAC operating mode disabled)
	b1 			- MSS			- 0 (Multi-port sweep mode disabled)
	b2			- CKS2			- 0 (Frequency select bit. fAD�1 selected)
	b4:b3		- MSF1:MSF0		- 00 (AN0 selected)
	b5:b6:b7	- Reserved		- 000 */
    
	ad0con3 = 0x0;
	
	/* ADC Control Register 4
	b1:b0		- Reserved		- 00
	b3:b2		- MPS11:MPS10	- 00 (Not used)
	b7:b6:b5:b4 - Reserved		- 0000 */
	
	ad0con4 = 0x00;
}
/*******************************************************************************
End of function ADC_Init
*******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline		: Convert_ADC_To_String
* Description	: Converts the unsigned short value into string
* Argument		: (unsigned short) num - value to be converted;
*				  (char*) buffer - pointer to output buffer (8 byte length).		
* Return value	: none
*��FUNC COMMENT END��*********************************************************/

void Convert_ADC_To_String(unsigned short num, char* buffer)
{
	char a;

	/* Store fixed string "ADC:" at first four locations */
	buffer[0] = 'A';
	buffer[1] = 'D';
	buffer[2] = 'C';
	buffer[3] = ':';
	
	/* Convert the ADC result into string.	*/
	a = (char)((num & 0xF000u) >> 12);
	buffer[4] = (a < 0x0A) ? (a+0x30):(a+0x37);
	a = (char)((num & 0x0F00) >> 8);
	buffer[5] = (a < 0x0A) ? (a+0x30):(a+0x37);
	a = (char)((num & 0x00F0) >> 4);
	buffer[6] = (a < 0x0A) ? (a+0x30):(a+0x37);
	a = (char)(num & 0x000F);
	buffer[7] = (a < 0x0A) ? (a+0x30):(a+0x37);
}
/******************************************************************************
End of function Convert_ADC_To_String
*******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline		: Convert_Ptr_To_String
* Description	: Converts the unsigned short value into string, also
*				  some extra characters are added.
* Argument		: (unsigned short) num - value to be converted;
*				  (char*) buffer - pointer to output buffer (8 byte length).	
* Return value	: none
*��FUNC COMMENT END��*********************************************************/

void Convert_Ptr_To_String(unsigned short num, char* buffer)
{
	char a;

	/* Store fixed string "Ptr:" at first four locations */
	buffer[0] = 'P';
	buffer[1] = 't';
	buffer[2] = 'r';
	buffer[3] = ':';
	
	/* Convert the pointer value into string.	*/
	a = (char)((num & 0xF000u)>> 12);
	buffer[4] = (a < 0x0A) ? (a+0x30):(a+0x37);
	a = (char)((num & 0x0F00)>> 8);
	buffer[5] = (a < 0x0A) ? (a+0x30):(a+0x37);
	a = (char)((num & 0x00F0)>> 4);
	buffer[6] = (a < 0x0A) ? (a+0x30):(a+0x37);
	a = (char)(num & 0x000F);
	buffer[7] = (a < 0x0A) ? (a+0x30):(a+0x37);
}
/*******************************************************************************
End of function Convert_Ptr_To_String
*******************************************************************************/

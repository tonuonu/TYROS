/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: flash_api_r32c.h
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Header file for flash_api_r32c.c 
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

#ifndef FLASH_API_R32C_H
#define FLASH_API_R32C_H

/******************************************************************************
Macro Defines
******************************************************************************/
/* Parameter Types */
#define 	FLASH_PTR_TYPE 				unsigned short far *
#define   	BUF_PTR_TYPE 				unsigned short far *	
#define		FLASH_COMMAND_WRITE_ADDR	0xFFFFF800ul

/* User Block Areas */
/*  32KB: FFFF8000h - FFFFFFFFh */
#define BLOCK_0		0		
/*  32KB: FFFF0000h - FFFF7FFFh */
#define BLOCK_1		1		
/*  32KB: FFFE8000h - FFFEFFFFh */
#define BLOCK_2		2		
/*  32KB: FFFE0000h - FFFE7FFFh */
#define BLOCK_3		3		
/*  64KB: FFFD0000h - FFFDFFFFh */
#define BLOCK_4		4		
/*  64KB: FFFC0000h - FFFCFFFFh */
#define BLOCK_5		5		
/*  64KB: FFFB0000h - FFFBFFFFh */
#define BLOCK_6		6		
/*  64KB: FFFA0000h - FFFAFFFFh */
#define BLOCK_7		7		
/*  64KB: FFF90000h - FFF9FFFFh */
#define BLOCK_8		8		
/*  64KB: FFF80000h - FFF8FFFFh */
#define BLOCK_9		9		

/* Data Block Areas */
/* 4KB: 00061000h - 00061FFFh */
#define BLOCK_A		10		
/* 4KB: 00060000h - 00060FFFh */
#define BLOCK_B		11		

/******************************************************************************
Function Prototypes
******************************************************************************/
void slowmcuclock(void);
void restoremcuclock(void);
unsigned char FlashEraseEW1(unsigned char block);
unsigned char FlashWriteEW1(FLASH_PTR_TYPE flash_addr, BUF_PTR_TYPE buffer_addr,
							unsigned short bytes);
							
#endif 

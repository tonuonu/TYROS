/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_repeat.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: This program demonstrates the configuration of ADC in repeat 
*				  mode. It configures the AD channel 'AN0' in continuous scan
*				  mode. Updated ADC result will be displayed on the debug LCD. 
*				  Note: If your power supply is not filtered enough you can 
*				  see some flickering on debug LCD. 
*
* Operation     :  1. Build this application and download it to target. 
*				   2. Click on the "Reset Go" icon available on 'Debug' toolbar.
*				   3. The result will be stored in a variable 'usADC_Result'. 
*				   4. The ADC result will also be displayed on the debug LCD.
*				   5. The onboard potentiometer can be used to change the 
*					  ADC input to the AD converter.				
*				   6. The user may examine the ADC conversion result in a 
*				      variable 'usADC_Result' using HEW C watch window. 
*				  
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
*******************************************************************************/
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include 	"main_repeat.h"
/* Following header file provides common defines for widely used items. */
#include	"rskr32c111def.h"
/*	Following header file provides useful macros and function prototypes for
	controlling the LCD interface.	*/
#include	"lcd.h"

/******************************************************************************
Global variables
*******************************************************************************/
/* Initialize the variable "usADC_Result" used to store the ADC result */
volatile unsigned short usADC_Result = 0;

/******************************************************************************
User Program Code
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description	: Main program. Calls initialization routines for ADC and debug
*				  LCD modules
* Argument		: none		
* Return value	: none
*��FUNC COMMENT END��*********************************************************/

void main(void)
{
	/* Array to store the ADC result. The hex result value is converted 
	into string and stored in this array */
	char strADC_Result[8];
	
	/* Initializes the debug LCD module  */
	InitialiseDisplay(); 

	/* Configure ADC to get AD reading from channel 0, repeat mode */
	ADC_Init();
	
	/* Display "ADC REP" message on debug LCD Line 1 */
	DisplayString(LCD_LINE1, "ADC REP ");

	/* ADC conversion start flag. Set to 1 to start ADC conversion */
	adst_ad0con0 = 1;  

	while (1)
	{
		/* Save the ADC conversion result in usADC_Result 
		ad0 - register to hold the ADC conversion result */
		usADC_Result = (unsigned short) ad00;
		
		/* Convert the hex value in string */
		Convert_Number_ToString(usADC_Result, strADC_Result);
	
		/* Display ADC Result on debug LCD Line 2 */
		DisplayString(LCD_LINE2, strADC_Result);
	}
}
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline		: ADC_Init
* Description	: Configures ADC channel AN0 in repeat mode, software triggered
* Argument		: none		
* Return value	: none
*��FUNC COMMENT END��*********************************************************/

void ADC_Init(void)
{
	/* ADC conversion start flag. Set to 0 to stop ADC conversion */
	adst_ad0con0 = 0;
	
	/* ADC Control Register 0 
	b2:b1:b0	- CH2:CH1:CH0	- 000 (Analog Input Pin Select Bit. AN0 selected)
	b4:b3		- MD1:MD0		- 01  (Repeat mode)
	b5			- TRG			- 0   (Software trigger)
	b6			- ADST			- 0   (AD conversion stopped)
	b7			- CKS0			- 1	  (Frequency select bit. fAD�1 selected) */

	ad0con0 = 0x88;
	
	/* ADC Control Register 1
	b1:b0	- SCAN1:SCAN0	- 00 (AN0 selected)
	b2		- MD2			- 0  (single sweep mode)
	b3		- BITS			- 1  (10 bit mode)
	b4		- CKS1			- 1  (Frequency select bit. fAD�1 selected)
	b5		- VCUT 			- 1  (VREF connected)
	b7:b6	- OPA1:OPA0		- 00 (No use of ANEX0 or ANEX1 pin) */				
	       
	ad0con1 = 0x38;
	
	/* ADC Control Register 2 
	b0		- SMP			- 1  (With sample & hold function)
	b2:b1	- APS1:APS0		- 00 (AN0 selected)
	b4:b3	- Reserved		- 00
	b5		- TRG0			- 0  (Not applicable in software trigger mode)
	b7:b6	- Reserved		- 00 */
	
	ad0con2 = 0x01;
	
	/* ADC Control Register 3
	b0			- DUS			- 0 (DMAC operating mode disabled)
	b1 			- MSS			- 0 (Multi-port sweep mode disabled)
	b2			- CKS2			- 0 (Frequency select bit. fAD�1 selected)
	b4:b3		- MSF1:MSF0		- 00 (AN0 selected)
	b5:b6:b7	- Reserved		- 000 */
           
	ad0con3 = 0x00;
    
	/* ADC Control Register 4
	b1:b0		- Reserved		- 00
	b3:b2		- MPS11:MPS10	- 00 (Not used)
	b7:b6:b5:b4 - Reserved		- 0000 */

	ad0con4 = 0x00;
}
/******************************************************************************
End of function ADC_Init
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline		: Convert_Number_ToString
* Description	: Converts an unsigned short value into string of hexadecimals.
* Argument		: (unsigned short) num - value to be converted;
*				  (char *) buffer - pointer to output buffer (8 bytes length).		
* Return value	: none
*��FUNC COMMENT END��*********************************************************/

void Convert_Number_ToString(unsigned short num, char* buffer)
{
	char a;

	/* "=H'" characters before string of hexadecimals */
	buffer[0] = '=';
	buffer[1] = 'H';
	buffer[2] = '\'';
	
	/* Forming the string of hexadecimals */
	a = (char)((num & 0x0F00)>> 8);
	buffer[3] = (a < 0x0A) ? (a+0x30):(a+0x37); 
	a = (char)((num & 0x00F0)>> 4);
	buffer[4] = (a < 0x0A) ? (a+0x30):(a+0x37); 
	a = (char)(num & 0x000F);
	buffer[5] = (a < 0x0A) ? (a+0x30):(a+0x37); 

	/* Add two spaces for string termination */
	buffer[6] = ' ';
	buffer[7] = ' ';
}
/******************************************************************************
End of function Convert_Number_ToString
******************************************************************************/

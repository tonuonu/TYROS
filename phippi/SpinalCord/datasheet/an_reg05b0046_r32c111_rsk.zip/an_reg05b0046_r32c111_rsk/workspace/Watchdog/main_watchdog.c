/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_watchdog.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Demonstration of R32C111 on-chip watchdog timer
*
* Operation: 	1. Turn the analog POT (RV1) to full anti-Clockwise position.
*    			2. Build this application and download it to the target.
*				3. Click on the "Reset Go" icon available on 'Debug Run' toolbar.
*				4. The LEDs will start blinking. 
*			    5. Turning the Analog POT in clockwise direction will reduce
*				   the speed of LED switching and how often the watchdog timer
*				   is accessed (to prevent it from timing out).
*		    	6. At almost full clockwise position of Analog POT, timer A0 will
*				   generate an interrupt which is more than the watchdog
*				   timer period (more than 1 sec.) and hence, a watchdog irq
*				   is generated..
*				7. This will result in LEDs staying lit and the code sitting
*				   in an endless loop. 
*
* Note : Please select the option 'Debugging a program that uses WDT' in the
*        'firmware location' tab of the Emulator settings' dialog box -  	
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include "main_watchdog.h"

/*******************************************************************************
User Program Code
*******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: main
* Description 	: Main program. Calls Timer, ADC & watchdog initialization
*				  functions. 
* Argument	 	: none
* Return value	: none
*��FUNC COMMENT END��**********************************************************/

void main(void)				
{
	/* Initialize timer A0 */
	tmr_init();		

	/* Initializes ADC channel 0 in repeat mode. */
	adc_init();

	/* Initialize watchdog timer */
	wdt_init();
	
	/* This function must not exit. */
	while(1);
}         
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: wdt_init
* Description 	: Initializes the watchdog timer.
* Argument 		: none
* Return value	: none
*��FUNC COMMENT END��**********************************************************/

void wdt_init(void)
{	
	/* watchdog timeout = Prescaler divided by 128 */
	wdc7 = 1; 

 	/*	Start Watchdog Timer by writing any value to wdts register  */
	wdts = 0;
}
/**********************************************************************************
End of function wdt_init
***********************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: tmr_init
* Description 	: Configures the timer A0 as follows -
*					Timer mode, clock - f/8, count down
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

void tmr_init(void)
{
	/* Timer 0 mode register,  
	b1:b0 	- TMOD0:TMOD1 - 00 (Operation mode select bit. Set to 00 for timer mode)
	b2 		- MR0 		  - 0  (Set to 0 for no pulse output)
	b4:b3 	- MR2:MR1 	  - 00 (Set to 00 for gate function not available)
	b5 		- MR3 		  - 0  (Set to 0 in timer mode)
	b7:b6 	- TCK0:TCK1   - 01 (Count source select bit. Set to 10 to select f8 
			  					frequency source) */
	ta0mr = 0x40;
			
	/* Timer A0 Counter register, starts counting down from  0x0fff */
	ta0 = (unsigned short)0x0fff;
		
	/* Disable Interrupts */
	DISABLE_IRQ	

	/* Interrupt Control Register for Timer A0
	b2:b0 	- ILVL2:ILVL0 	- 001 (Interrupt priority 4 selected for Timer A0)
	b3 		- IR		 	- 0 (Interrupt request bit. Set to 0)
	b4 		- POL 			- 0 (Polarity select bit. Set to 0)  
	b5 		- Reserved		- Set to 0
	b7:b6 	- Reserved		- Set to 0 */
	ta0ic = 0x04;

	/* Enable Interrupts */
	ENABLE_IRQ	
		   
	/* Start timer A0 */
	ta0s = 1; 		
}
/**********************************************************************************
End of function tmr_init
***********************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: adc_init
* Description 	: Configures the ADC channel AN0 as follows -
*				  One Shot, software triggered
* Argument	 	: none
* Return value	: none
*��FUNC COMMENT END��**********************************************************/

void adc_init(void)
{
     /* ADC control register 0 
    10000000;  ** AN0 input, repeat mode, soft trigger, fAD
    b2:b0	-CH2:CH0	  -000 Analog input select bit (CH 0 selected as an input)    	 
    b4:b3	-MD1,MD0	  -00  A/D operation mode select bits (Repeat mode selected )
    b5		-TRG		  -0   Trigger select bit (Software Trigger selected)
    b6		-ADST	      -0   A/D conversion start flag (ADC conversion not started )
    b7		-CKS0   	  -1   Frequency select bit 0 (fAD)	*/

	ad0con0 = 0x80;


	/*	ADC control register 1 
    b1:b0	SCAN1:0		-00 A/D sweep pin select bits (not applicable in this mode)
    b2		MD2			-0  A/D operation mode select bit 1 (not applicable in this mode)
    b3		BITS		-1  8/10 bit mode select bit (10-bit mode)
    b4		CKS1		-1  Frequency select bit 1 (dependent on CKS0 bit in ADCCON0 ,fAD)
    b5		VCUT		-1  Vref connect bit (VREF connected)
    b7:b6	OPA1:OPA0	-00 External op-amp connection mode bitS (No use of ANEX pins)	*/

	ad0con1 = 0x38;

	/* ADC Control Register 2 
	b0		- SMP			- 1  (With sample & hold function)
	b2:b1	- APS1:APS0		- 00 (AN0 selected)
	b4:b3	- Reserved		- 00
	b5		- TRG0			- 0  (External Trigger Request. Select ADTRG pin)
	b7:b6	- Reserved		- 00 */
	                        	
    ad0con2 = 0x01;

	/* ADC Control Register 3
	b0			- DUS			- 0 (DMAC operating mode disabled)
	b1 			- MSS			- 0 (Multi-port sweep mode disabled)
	b2			- CKS2			- 0 (Frequency select bit. fAD�1 selected)
	b4:b3		- MSF1:MSF0		- 00 (AN0 selected)
	b5:b6:b7	- Reserved		- 000 */
	
    ad0con3 = 0x00;

	/* ADC Control Register 4
	b1:b0		- Reserved		- 00
	b3:b2		- MPS11:MPS10	- 00 (Not used)
	b7:b6:b5:b4 - Reserved		- 0000 */

	ad0con4 = 0x00;
        
	/* Start the ADC conversion */
	adst_ad0con0 = 1;  
}
/**********************************************************************************
End of function adc_init
***********************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: _timer_a0
* Description 	: Interrupt Handler for Timer A0
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

#pragma interrupt _timer_a0(vect=12)
void _timer_a0(void)
{
	/* This variable is used to multiply the timer period by a fixed multiplier 
    value in order to achieve the  watchdog interrupt at extreme clockwise position. */
	static unsigned char uc_cnt1;

	/* This variable is used to repeat the LED blinking pattern in a loop.	*/
	static unsigned char uc_cnt2;
	
	/* TIMER_PERIOD_MULTIPLIER has been used to ensure that the watchdog underflow 
		occurs exactly near extreme anti-clockwise position of the analog POT.	*/
	if(++uc_cnt1 > TIMER_PERIOD_MULTIPLIER)
	{
		/* Reset the watchdog timer	*/
		wdts = 0x00;
		uc_cnt1 = 0;
	}

	/* If ADC conversion is complete */
	if (adst_ad0con0 == 0)
	{
		if(ad00 > 500)
		{
			/* load the timer ta0 with the value of ADC result */
			ta0 = (ad00 * 63); 
		}	
		
		else
		{
			/* To make the flashing visible when the pot is fully anti-clockwise	*/
			ta0 = 23000; 		
		}

		/* Re-start the A/D */
		adst_ad0con0 = 1;
	} 
	
	/* This loop ensures that the pattern of blinking LEDs is repeated
	   periodically */
	if(++uc_cnt2 > 5)
	{
		/* Reset the count so as to start again with LED2 ON.	*/
		uc_cnt2 = 1;
	}

	switch (uc_cnt2)
	{
		/* LED2 ON. LED0 & LED1 OFF	*/
		case 1:							
   				LED0 = LED_OFF;			
				LED1 = LED_OFF;
				LED2 = LED_OFF;
				LED3 = LED_ON;
				break;
				
		/* LED1 ON. LED0 & LED2 OFF	*/
		case 2:	
				LED0 = LED_OFF;			
				LED1 = LED_OFF;
				LED2 = LED_ON;
				LED3 = LED_OFF;
				break;						
		case 4:
   				LED0 = LED_OFF;			
				LED1 = LED_ON;
				LED2 = LED_OFF;
				LED3 = LED_OFF;
				break;

		/* LED0 ON. LED1 & LED2 OFF	*/
		case 3:							
   				LED0 = LED_ON;			
				LED1 = LED_OFF;
				LED2 = LED_OFF;
				LED3 = LED_OFF;
				break;

		/* LED0, LED1 LED2 are OFF	*/
		default:						
   				LED0 = LED_OFF;			
				LED1 = LED_OFF;
				LED2 = LED_OFF;
				LED3 = LED_OFF;
	}
}
/******************************************************************************
End of ISR _timer_a0
******************************************************************************/

/*��FUNC COMMENT��**************************************************************
* Outline 		: _wdt_irq
* Description 	: Interrupt handler for Watchdog timer
*				  When the watchdog timer underflows, this routine is executed
*				  and the program loops here forever.
* Argument	 	: none
* Return value  : none
*��FUNC COMMENT END��**********************************************************/

#pragma interrupt	_wdt_irq
void _wdt_irq(void)
{
	/* This loop must not exit once entered. */
	while(1)
	{
		/* Turn ON LEDs to indicate that WDT interrupt has occurred. */
		LED0 = LED_ON;	 
		LED1 = LED_ON;
		LED2 = LED_ON;
		LED3 = LED_ON;
		/* Reset the watchdog timer */
		wdts = 0x00;
	}
}
/**********************************************************************************
End of function wdt_irq
***********************************************************************************/

/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: main_pulseout.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: main routine for Timer - Pulse Output Mode
*                 Generates a 1 KHz square waveform on TA3 output (P7_6) 
* 				  which can be monitored at pin JA5-5 on RSKR32C111.
*
* Operation     : 1. Connect oscilloscope probe at JA5-5 (J1-31) and observe
*					 the pulse.
*				  2. Build this application and download it to the target. 
*				  3. Click on the "Reset Go" icon available on 'Debug' toolbar.  
*				  4. Waveform of 1KHz frequency will be generated .

******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides common defines for widely used items. */
#include "rskr32c111def.h"	
/*	Following header file provides a structure to access on-chip I/O
    registers. */
#include "sfr111.h"
/*	Following header file provides prototypes for the functions defined in this
	file.	*/
#include 	"main_pulseout.h"

/*****************************************************************************
Global variables
*****************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: main
* Description 	: Main program. Calls initialization routine for timer
*				  initialisation 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void main (void)
{ 
	/* Configure the timer in pulse output mode. 	*/
	tmr_init();
  	
	/* This loop will never exit.	*/
	while (1);      
}
/******************************************************************************
End of function main
******************************************************************************/

/*��FUNC COMMENT��*************************************************************
* Outline 		: tmr_init
* Description 	: Setup timer A3 setup in Pulse Output Mode. 
* Argument  	: none
* Return value  : none
*��FUNC COMMENT END��*********************************************************/

void tmr_init(void)
{
	/* Configure the port pin to provide pulse output	*/
	p7_6s = 1;
	pd7_6 = 1;

	/*setting the timer value for 1KHz frequency*/
	ta3 = (unsigned short) (((f1_CLK_SPEED/16)/1000)-1);
	
	/*  ta3 mode register
	  b1:b0	- TMOD0,TMOD1 - 00 (Timer mode selected)
   	  b2 	- MR0		  - 0 (Set to 0)
  	  b4:b3 - MR2:MR1	  - 0 (Gate function note selected)
   	  b5	- MR3		  - 0 (Set to 0 in timer mode)
   	  b7:b6	- TCK1,TCK0   - f/8 clock source selected
  	  b7	- UFORM		 - 0 (LSB first selected) */

   	ta3mr = 0x40;  

    /*start timer */ 
	ta3s = 1;      
}
/******************************************************************************
End of function tmr_init
******************************************************************************/

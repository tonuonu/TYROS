/******************************************************************************
* DISCLAIMER:
* The software supplied by Renesas Technology Europe Ltd is
* intended and supplied for use on Renesas Technology products.
* This software is owned by Renesas Technology Europe, Ltd. Or
* Renesas Technology Corporation and is protected under applicable
* copyright laws. All rights are reserved.
*
* THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,
* IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* APPLY TO THIS SOFTWARE. RENESAS TECHNOLOGY AMERICA, INC. AND
* AND RENESAS TECHNOLOGY CORPORATION RESERVE THE RIGHT, WITHOUT
* NOTICE, TO MAKE CHANGES TO THIS SOFTWARE. NEITHER RENESAS
* TECHNOLOGY AMERICA, INC. NOR RENESAS TECHNOLOGY CORPORATION SHALL,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
* CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER ARISING OUT OF THE
* USE OR APPLICATION OF THIS SOFTWARE.
******************************************************************************/

/* Copyright (C) 2008. Renesas Technology Europe, All Rights Reserved */

/*��FILE COMMENT��******************************* Technical reference data ****
* File Name		: intprg.c
* Version 		: 1.00
* Device 		: R32C/111 (R5F64112DFB)
* Tool Chain 	: HEW, R32C Toolchain v1.01
* H/W Platform	: RSKR32C111
* Description 	: Define a variable vector table R32C/111
******************************************************************************/

/******************************************************************************
* History 		: 21.11.2008 Ver. 1.00 First Release
*��FILE COMMENT END��*********************************************************/

/******************************************************************************
User Includes (Project level includes)
******************************************************************************/
/* Following header file provides a structure to access all of the device
   registers. */
#include "sfr111.h"

/******************************************************************************
Interrupt vectors
******************************************************************************/
/* BRK				(software int 0) */
#pragma interrupt	_brk(vect=0)
void _brk(void);
void _brk(void){}

/* RAM ECC error	(software int 1) */
#pragma interrupt	_ram_ecc_error(vect=1)
void _ram_ecc_error(void);
void _ram_ecc_error(void){}

/* uart5 trans/NACK		(software int 2) */
#pragma interrupt	_uart5_trans(vect=2)
void _uart5_trans(void);
void _uart5_trans(void){}

/* uart5 receive/ACK		(software int 3) */
#pragma interrupt	_uart5_receive(vect=3)
void _uart5_receive(void);
void _uart5_receive(void){}

/* uart6 trans/NACK		(software int 4) */
#pragma interrupt	_uart6_trans(vect=4)
void _uart6_trans(void);
void _uart6_trans(void){}

/* uart6 receive/ACK		(software int 5) */
#pragma interrupt	_uart6_receive(vect=5)
void _uart6_receive(void);
void _uart6_receive(void){}

/* Bus Collision/start/stop condition(uart5/uart6)	(software int 6) */
#pragma interrupt	_bus_collision_u5_u6(vect=6)
void _bus_collision_u5_u6(void);
void _bus_collision_u5_u6(void){}

/* vector 7 reserved */

/* DMA0				(software int 8) */
#pragma interrupt	_dma0(vect=8)
void _dma0(void);
void _dma0(void){}

/* DMA1				(software int 9) */
#pragma interrupt	_dma1(vect=9)
void _dma1(void);
void _dma1(void){}

/* DMA2				(software int 10) */
#pragma interrupt	_dma2(vect=10)
void _dma2(void);
void _dma2(void){}

/* DMA3				(software int 11) */
#pragma interrupt	_dma3(vect=11)
void _dma3(void);
void _dma3(void){}

/* TIMER A0			(software int 12) */
#pragma interrupt	_timer_a0(vect=12)
void _timer_a0(void);
void _timer_a0(void){} 

/* TIMER A1			(software int 13) */
#pragma interrupt	_timer_a1(vect=13)
void _timer_a1(void);
void _timer_a1(void){}

/* TIMER A2			(software int 14) */
#pragma interrupt	_timer_a2(vect=14)
void _timer_a2(void);
void _timer_a2(void){}

/* TIMER A3			(software int 15) */
#pragma interrupt	_timer_a3(vect=15)
void _timer_a3(void);
void _timer_a3(void){}

/* TIMER A4			(software int 16) */
#pragma interrupt	_timer_a4(vect=16)
void _timer_a4(void);
void _timer_a4(void){}

/* uart0 trans/NACK		(software int 17) */
#pragma interrupt	_uart0_trans(vect=17)
void _uart0_trans(void);
void _uart0_trans(void){}

/* uart0 receive/ACK		(software int 18) */
/*#pragma interrupt	_uart0_receive(vect=18)
void _uart0_receive(void);
void _uart0_receive(void){} */

/* uart1 trans/NACK		(software int 19) */
#pragma interrupt	_uart1_trans(vect=19)
void _uart1_trans(void);
void _uart1_trans(void){}

/* uart1 receive/ACK		(software int 20) */
#pragma interrupt	_uart1_receive(vect=20)
void _uart1_receive(void);
void _uart1_receive(void){}

/* TIMER B0			(software int 21) */
#pragma interrupt	_timer_b0(vect=21)
void _timer_b0(void);
void _timer_b0(void){}

/* TIMER B1			(software int 22) */
#pragma interrupt	_timer_b1(vect=22)
void _timer_b1(void);
void _timer_b1(void){}

/* TIMER B2			(software int 23) */
#pragma interrupt	_timer_b2(vect=23)
void _timer_b2(void);
void _timer_b2(void){}

/* TIMER B3			(software int 24) */
#pragma interrupt	_timer_b3(vect=24)
void _timer_b3(void);
void _timer_b3(void){}

/* TIMER B4			(software int 25) */
#pragma interrupt	_timer_b4(vect=25)
void _timer_b4(void);
void _timer_b4(void){}

/* INT5				(software int 26) */
#pragma interrupt	_int5(vect=26)
void _int5(void);
void _int5(void){}

/* INT4				(software int 27) */
#pragma interrupt	_int4(vect=27)
void _int4(void);
void _int4(void){}

/* INT3				(software int 28) */
#pragma interrupt	_int3(vect=28)
void _int3(void);
void _int3(void){}

/* INT2				(software int 29) */
#pragma interrupt	_int2(vect=29)
void _int2(void);
void _int2(void){}

/* INT1				(software int 30) */
#pragma interrupt	_int1(vect=30)
void _int1(void);
void _int1(void){} 

/* INT0				(software int 31) */
#pragma interrupt	_int0(vect=31)
void _int0(void);
void _int0(void){} 

/* Timer B5			(software int 32) */
#pragma interrupt	_timer_b5(vect=32)
void _timer_b5(void);
void _timer_b5(void){}

/* uart2 trans/NACK		(software int 33) */
#pragma interrupt	_uart2_trans(vect=33)
void _uart2_trans(void);
void _uart2_trans(void){}

/* uart2 receive/ACK		(software int 34) */
#pragma interrupt	_uart2_receive(vect=34)
void _uart2_receive(void);
void _uart2_receive(void){}

/* uart3 trans/NACK		(software int 35) */
#pragma interrupt	_uart3_trans(vect=35)
void _uart3_trans(void);
void _uart3_trans(void){}

/* uart3 receive/ACK		(software int 36) */
#pragma interrupt	_uart3_receive(vect=36)
void _uart3_receive(void);
void _uart3_receive(void){}

/* uart4 trans/NACK		(software int 37) */
#pragma interrupt	_uart4_trans(vect=37)
void _uart4_trans(void);
void _uart4_trans(void){}

/* uart4 receive/ACK		(software int 38) */
#pragma interrupt	_uart4_receive(vect=38)
void _uart4_receive(void);
void _uart4_receive(void){}

/* Bus Collision/start/stop condition(uart2)	(software int 39) */
#pragma interrupt	_bus_collision_u2(vect=39)
void _bus_collision_u2(void);
void _bus_collision_u2(void){}

/* Bus Collision/start/stop condition(uart1/uart4)	(software int 40) */
#pragma interrupt	_bus_collision_u1_u4(vect=40)
void _bus_collision_u1_u4(void);
void _bus_collision_u1_u4(void){}

/* Bus Collision/start/stop condition(uart1)	(software int 41) */
#pragma interrupt	_bus_collision_u1(vect=41)
void _bus_collision_u1(void);
void _bus_collision_u1(void){}

/* A-D0				(software int 42) */
#pragma interrupt	_ad_converter0(vect=42)
void _ad_converter0(void);
void _ad_converter0(void){}

/* key input 		(software int 43) */
#pragma interrupt	_key_input(vect=43)
void _key_input(void);
void _key_input(void){}

/* intelligent I/O interrupt 0	(software int 44) */
#pragma interrupt	_intelligent_io_int0(vect=44)
void _intelligent_io_int0(void);
void _intelligent_io_int0(void){}

/* intelligent I/O interrupt 1	(software int 45) */
#pragma interrupt	_intelligent_io_int1(vect=45)
void _intelligent_io_int1(void);
void _intelligent_io_int1(void){}

/* intelligent I/O interrupt 2	(software int 46) */
#pragma interrupt	_intelligent_io_int2(vect=46)
void _intelligent_io_int2(void);
void _intelligent_io_int2(void){}

/* intelligent I/O interrupt 3	(software int 47) */
#pragma interrupt	_intelligent_io_int3(vect=47)
void _intelligent_io_int3(void);
void _intelligent_io_int3(void){}

/* intelligent I/O interrupt 4	(software int 48) */
#pragma interrupt	_intelligent_io_int4(vect=48)
void _intelligent_io_int4(void);
void _intelligent_io_int4(void){}

/* intelligent I/O interrupt 5	(software int 49) */
#pragma interrupt	_intelligent_io_int5(vect=49)
void _intelligent_io_int5(void);
void _intelligent_io_int5(void){}

/* intelligent I/O interrupt 6	(software int 50) */
#pragma interrupt	_intelligent_io_int6(vect=50)
void _intelligent_io_int6(void);
void _intelligent_io_int6(void){}

/* intelligent I/O interrupt 7	(software int 51) */
#pragma interrupt	_intelligent_io_int7(vect=51)
void _intelligent_io_int7(void);
void _intelligent_io_int7(void){}

/* intelligent I/O interrupt 8	(software int 52) */
#pragma interrupt	_intelligent_io_int8(vect=52)
void _intelligent_io_int8(void);
void _intelligent_io_int8(void){}

/* intelligent I/O interrupt 9	(software int 53) */
#pragma interrupt	_intelligent_io_int9(vect=53)
void _intelligent_io_int9(void);
void _intelligent_io_int9(void){}

/* intelligent I/O interrupt 10	(software int 54) */
#pragma interrupt	_intelligent_io_int10(vect=54)
void _intelligent_io_int10(void);
void _intelligent_io_int10(void){}

/* intelligent I/O interrupt 11	(software int 55) */
#pragma interrupt	_intelligent_io_int11(vect=55)
void _intelligent_io_int11(void);
void _intelligent_io_int11(void){}

/* vector 56 reserved */
/* vector 57 reserved */
/* vector 58 reserved */

/* CAN1 wake up	(software int 59) */
#pragma interrupt	_can1wu(vect=59)
void _can1wu(void);
void _can1wu(void){}

/* vector 60 reserved */
/* vector 61 reserved */
/* vector 62 reserved */
/* vector 63 reserved */
/* vector 64 reserved */
/* vector 65 reserved */
/* vector 66 reserved */
/* vector 67 reserved */
/* vector 68 reserved */
/* vector 69 reserved */
/* vector 70 reserved */
/* vector 71 reserved */
/* vector 72 reserved */
/* vector 73 reserved */
/* vector 74 reserved */
/* vector 75 reserved */
/* vector 76 reserved */
/* vector 77 reserved */
/* vector 78 reserved */
/* vector 79 reserved */
/* vector 80 reserved */
/* vector 81 reserved */
/* vector 82 reserved */
/* vector 83 reserved */
/* vector 84 reserved */
/* vector 85 reserved */
/* vector 86 reserved */
/* vector 87 reserved */
/* vector 88 reserved */
/* vector 89 reserved */
/* vector 90 reserved */
/* vector 91 reserved */
/* vector 92 reserved */
/* vector 93 reserved */
/* vector 94 reserved */
/* vector 95 reserved */

/* CAN0 trans		(software int 96) */
#pragma interrupt	_can0_trans(vect=96)
void _can0_trans(void);
void _can0_trans(void){}

/* CAN0 receive		(software int 97) */
#pragma interrupt	_can0_receive(vect=97)
void _can0_receive(void);
void _can0_receive(void){}

/* CAN0 error		(software int 98) */
#pragma interrupt	_can0_error(vect=98)
void _can0_error(void);
void _can0_error(void){}

/* CAN1 trans		(software int 99) */
#pragma interrupt	_can1_trans(vect=99)
void _can1_trans(void);
void _can1_trans(void){}

/* CAN1 receive		(software int 100) */
#pragma interrupt	_can1_receive(vect=100)
void _can1_receive(void);
void _can1_receive(void){}

/* CAN1 error		(software int 101) */
#pragma interrupt	_can1_error(vect=101)
void _can1_error(void);
void _can1_error(void){}

/* vector 102 reserved */
/* vector 103 reserved */
/* vector 104 reserved */
/* vector 105 reserved */
/* vector 106 reserved */
/* vector 107 reserved */
/* vector 108 reserved */
/* vector 109 reserved */
/* vector 110 reserved */
/* vector 111 reserved */
/* vector 112 reserved */
/* vector 113 reserved */
/* vector 114 reserved */
/* vector 115 reserved */
/* vector 116 reserved */
/* vector 117 reserved */
/* vector 118 reserved */
/* vector 119 reserved */
/* vector 120 reserved */
/* vector 121 reserved */
/* vector 122 reserved */
/* vector 123 reserved */

/* uart7 trans		(software int 124) */
#pragma interrupt	_uart7_trans(vect=124)
void _uart7_trans(void);
void _uart7_trans(void){}

/* uart7 receive		(software int 125) */
#pragma interrupt	_uart7_receive(vect=125)
void _uart7_receive(void);
void _uart7_receive(void){}

/* uart8 trans		(software int 126) */
#pragma interrupt	_uart8_trans(vect=126)
void _uart8_trans(void);
void _uart8_trans(void){}

/* uart8 receive		(software int 127) */
#pragma interrupt	_uart8_receive(vect=127)
void _uart8_receive(void);
void _uart8_receive(void){}

/* vector 128 reserved */
/* vector 129 reserved */
/* vector 130 reserved */
/* vector 131 reserved */
/* vector 132 reserved */
/* vector 133 reserved */
/* vector 134 reserved */
/* vector 135 reserved */
/* vector 136 reserved */
/* vector 137 reserved */
/* vector 138 reserved */
/* vector 139 reserved */
/* vector 140 reserved */
/* vector 141 reserved */
/* vector 142 reserved */
/* vector 143 reserved */
/* vector 144 reserved */
/* vector 145 reserved */
/* vector 146 reserved */
/* vector 147 reserved */
/* vector 148 reserved */
/* vector 149 reserved */
/* vector 150 reserved */
/* vector 151 reserved */
/* vector 152 reserved */
/* vector 153 reserved */
/* vector 154 reserved */
/* vector 155 reserved */
/* vector 156 reserved */
/* vector 157 reserved */
/* vector 158 reserved */
/* vector 159 reserved */
/* vector 160 reserved */
/* vector 161 reserved */
/* vector 162 reserved */
/* vector 163 reserved */
/* vector 164 reserved */
/* vector 165 reserved */
/* vector 166 reserved */
/* vector 167 reserved */
/* vector 168 reserved */
/* vector 169 reserved */
/* vector 170 reserved */
/* vector 171 reserved */
/* vector 172 reserved */
/* vector 173 reserved */
/* vector 174 reserved */
/* vector 175 reserved */
/* vector 176 reserved */
/* vector 177 reserved */
/* vector 178 reserved */
/* vector 179 reserved */
/* vector 180 reserved */
/* vector 181 reserved */
/* vector 182 reserved */
/* vector 183 reserved */
/* vector 184 reserved */
/* vector 185 reserved */
/* vector 186 reserved */
/* vector 187 reserved */
/* vector 188 reserved */
/* vector 189 reserved */
/* vector 190 reserved */
/* vector 191 reserved */
/* vector 192 reserved */
/* vector 193 reserved */
/* vector 194 reserved */
/* vector 195 reserved */
/* vector 196 reserved */
/* vector 197 reserved */
/* vector 198 reserved */
/* vector 199 reserved */
/* vector 200 reserved */
/* vector 201 reserved */
/* vector 202 reserved */
/* vector 203 reserved */
/* vector 204 reserved */
/* vector 205 reserved */
/* vector 206 reserved */
/* vector 207 reserved */
/* vector 208 reserved */
/* vector 209 reserved */
/* vector 210 reserved */
/* vector 211 reserved */
/* vector 212 reserved */
/* vector 213 reserved */
/* vector 214 reserved */
/* vector 215 reserved */
/* vector 216 reserved */
/* vector 217 reserved */
/* vector 218 reserved */
/* vector 219 reserved */
/* vector 220 reserved */
/* vector 221 reserved */
/* vector 222 reserved */
/* vector 223 reserved */
/* vector 224 reserved */
/* vector 225 reserved */
/* vector 226 reserved */
/* vector 227 reserved */
/* vector 228 reserved */
/* vector 229 reserved */
/* vector 230 reserved */
/* vector 231 reserved */													
/* vector 232 reserved */
/* vector 233 reserved */
/* vector 234 reserved */
/* vector 235 reserved */
/* vector 236 reserved */
/* vector 237 reserved */
/* vector 238 reserved */
/* vector 239 reserved */
/* vector 240 reserved */
/* vector 241 reserved */
/* vector 242 reserved */
/* vector 243 reserved */
/* vector 244 reserved */
/* vector 245 reserved */
/* vector 246 reserved */
/* vector 247 reserved */
/* vector 248 reserved */
/* vector 249 reserved */
/* vector 250 reserved */
/* vector 251 reserved */
/* vector 252 reserved */
/* vector 253 reserved */
/* vector 254 reserved */
/* vector 255 reserved */
